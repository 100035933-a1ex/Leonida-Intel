// Leonida Intel static build. Zero dependencies: needs only Node 18+.
//   node build.mjs        -> writes the finished site to ./dist
// Vercel runs this via vercel.json ("buildCommand") and serves ./dist.
import { rmSync, mkdirSync, writeFileSync, readFileSync, cpSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";

import { SITE } from "./src/site.mjs";
import { ctx } from "./src/render.mjs";
import { cardArt, artKind } from "./src/art.mjs";
import * as P from "./src/pages.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const dist = join(root, "dist");
const pub = join(root, "public");

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
cpSync(pub, dist, { recursive: true });

// Cache-busting version derived from the CSS/JS contents.
const h = createHash("sha1");
for (const f of ["styles.css", "app.js"]) h.update(readFileSync(join(pub, f)));
ctx.assetVersion = h.digest("hex").slice(0, 8);

// Pages are written as flat "name.html" files. Vercel's cleanUrls serves /news from news.html
// and /news/slug from news/slug.html, so direct links and refreshes work with no rewrites.
const pages = [
  P.home(), P.newsIndex(), ...P.newsArticles(), P.updatesPage(), P.rumorsIndex(), ...P.rumorPages(),
  P.questionsPage(), P.guidesIndex(), ...P.guidePages(), P.membership(), P.searchPage(), P.watchlistPage(),
  P.aboutPage(), P.notFoundPage(),
];

const written = [];
for (const p of pages) {
  const file = p.file || (p.path === "/" ? "index.html" : `${p.path.slice(1)}.html`);
  const full = join(dist, file);
  mkdirSync(dirname(full), { recursive: true });
  writeFileSync(full, p.html);
  written.push({ path: p.path, file });
}

// Card artwork (unique per item) and the search index.
mkdirSync(join(dist, "assets", "art"), { recursive: true });
for (const a of P.allCardArt()) {
  writeFileSync(join(dist, "assets", "art", `${a.type}-${a.slug}.svg`), cardArt(a.slug, artKind(a.type, a.category)));
}
const index = P.buildSearchIndex();
writeFileSync(join(dist, "search-index.json"), JSON.stringify(index));

// robots.txt and sitemap.xml (sitemap only when the public URL is known).
const noindex = new Set(["/404", "/watchlist"]);
let robots = "User-agent: *\nAllow: /\n";
if (SITE.baseUrl) {
  const urls = written.filter((w) => !noindex.has(w.path)).map((w) => `<url><loc>${SITE.baseUrl}${w.path === "/" ? "/" : w.path}</loc><lastmod>${SITE.lastReviewed}</lastmod></url>`);
  writeFileSync(join(dist, "sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>\n`);
  robots += `Sitemap: ${SITE.baseUrl}/sitemap.xml\n`;
}
writeFileSync(join(dist, "robots.txt"), robots);

if (!existsSync(join(dist, "assets", "og-image.png"))) console.warn("warning: public/assets/og-image.png is missing");
console.log(`Built ${written.length} pages, ${index.length} search entries, assets v${ctx.assetVersion} -> dist/`);
if (!SITE.baseUrl) console.log("note: SITE_URL not set; canonical URLs and sitemap.xml are skipped (Vercel sets them automatically in production).");
