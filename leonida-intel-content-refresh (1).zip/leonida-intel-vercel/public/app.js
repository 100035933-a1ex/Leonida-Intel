/* Leonida Intel: progressive enhancement. Pages are complete HTML without this file;
   JS adds navigation toggling, filters, search, the watchlist and the demo question form. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  var fmtDate = function (iso) { var p = iso.split("-").map(Number); return MONTHS[p[1] - 1] + " " + p[2] + ", " + p[0]; };
  var todayIso = function () { var d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };

  /* ---------- Toast ---------- */
  var toastTimer;
  function toast(msg) {
    var t = $("#toast"); if (!t) return;
    t.textContent = msg; t.classList.add("is-visible");
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove("is-visible"); }, 2800);
  }

  /* ---------- Navigation ---------- */
  (function nav() {
    var btn = $(".nav-toggle"), menu = $("#site-nav"); if (!btn || !menu) return;
    function set(open) { menu.classList.toggle("is-open", open); btn.setAttribute("aria-expanded", String(open)); }
    btn.addEventListener("click", function () { set(btn.getAttribute("aria-expanded") !== "true"); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && menu.classList.contains("is-open")) { set(false); btn.focus(); } });
    document.addEventListener("click", function (e) { if (menu.classList.contains("is-open") && !menu.contains(e.target) && !btn.contains(e.target)) set(false); });
    menu.addEventListener("click", function (e) { if (e.target.closest("a")) set(false); });
    window.matchMedia("(min-width:1021px)").addEventListener("change", function (m) { if (m.matches) set(false); });
  })();

  /* ---------- Watchlist (browser localStorage; no accounts, no sync) ---------- */
  var KEY = "leonida-intel:watchlist:v1";
  var memory = [];
  var storageOk = true;
  function readList() {
    try { var raw = localStorage.getItem(KEY); var v = raw ? JSON.parse(raw) : []; return Array.isArray(v) ? v.filter(function (x) { return x && typeof x.id === "string"; }) : []; }
    catch (e) { storageOk = false; return memory.slice(); }
  }
  function writeList(list) {
    memory = list.slice();
    try { localStorage.setItem(KEY, JSON.stringify(list)); return true; } catch (e) { storageOk = false; return false; }
  }
  var has = function (id) { return readList().some(function (x) { return x.id === id; }); };
  function toggle(id) {
    var list = readList(), i = list.findIndex(function (x) { return x.id === id; });
    if (i >= 0) { list.splice(i, 1); writeList(list); changed(); return false; }
    list.unshift({ id: id, t: Date.now() });
    if (!writeList(list) && !storageOk) { toast("Couldn’t save: your browser is blocking local storage."); return null; }
    changed(); return true;
  }
  function remove(id) { writeList(readList().filter(function (x) { return x.id !== id; })); changed(); }
  function changed() { document.dispatchEvent(new CustomEvent("watchlist:change")); }
  function syncButtons(root) {
    var ids = readList().map(function (x) { return x.id; });
    $$("[data-save]", root).forEach(function (b) {
      var on = ids.indexOf(b.getAttribute("data-save")) >= 0;
      b.setAttribute("aria-pressed", String(on));
      var l = $(".save__label", b); if (l) l.textContent = on ? "Saved" : "Save";
    });
    var n = ids.length;
    $$("[data-watch-count]").forEach(function (c) { c.textContent = String(n); c.hidden = n === 0; c.setAttribute("aria-label", n + " saved"); });
  }
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-save]"); if (!b) return;
    var res = toggle(b.getAttribute("data-save"));
    if (res === true) toast("Saved to your watchlist (this browser only).");
    else if (res === false) toast("Removed from your watchlist.");
  });
  document.addEventListener("watchlist:change", function () { syncButtons(document); });
  window.addEventListener("storage", function (e) { if (e.key === KEY) { syncButtons(document); changed(); } });
  syncButtons(document);

  /* ---------- Generic list filters (News, Updates, Rumors, Questions, Guides) ---------- */
  function initFilters(root) {
    var list = $("[data-list]", root), items = $$("[data-item]", list), q = $("[data-q]", root), sort = $("[data-sort]", root);
    var groups = $$(".chips[data-group]", root), count = $("[data-count]", root), empty = $("[data-empty]", root);
    var state = { q: "", sort: "newest" }; groups.forEach(function (g) { state[g.getAttribute("data-group")] = "all"; });
    var params = new URLSearchParams(location.search);
    if (params.get("q")) state.q = params.get("q");
    groups.forEach(function (g) {
      var n = g.getAttribute("data-group"), v = params.get(n);
      if (v && $$("button", g).some(function (b) { return b.getAttribute("data-value") === v; })) state[n] = v;
    });
    if (sort && params.get("sort") === "oldest") state.sort = "oldest";

    function apply(push) {
      var tokens = state.q.toLowerCase().split(/\s+/).filter(Boolean), shown = 0;
      items.forEach(function (it) {
        var ok = tokens.every(function (t) { return (it.getAttribute("data-text") || "").indexOf(t) >= 0; });
        groups.forEach(function (g) {
          var n = g.getAttribute("data-group"), v = state[n];
          if (ok && v !== "all") ok = (it.getAttribute("data-" + n) || "").split("|").indexOf(v) >= 0;
        });
        it.classList.toggle("is-hidden", !ok); if (ok) shown++;
      });
      var dir = state.sort === "oldest" ? 1 : -1;
      items.slice().sort(function (a, b) { var x = a.getAttribute("data-date"), y = b.getAttribute("data-date"); return x < y ? dir * -1 : x > y ? dir : 0; })
        .forEach(function (it) { list.appendChild(it); });
      groups.forEach(function (g) { $$("button", g).forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-value") === state[g.getAttribute("data-group")])); }); });
      if (q && q.value !== state.q) q.value = state.q;
      if (sort) sort.value = state.sort;
      if (count) count.textContent = "Showing " + shown + " of " + items.length;
      if (empty) empty.hidden = shown !== 0;
      list.hidden = shown === 0;
      var p = new URLSearchParams();
      if (state.q) p.set("q", state.q);
      groups.forEach(function (g) { var n = g.getAttribute("data-group"); if (state[n] !== "all") p.set(n, state[n]); });
      if (sort && state.sort !== "newest") p.set("sort", state.sort);
      var qs = p.toString();
      history.replaceState(null, "", location.pathname + (qs ? "?" + qs : "") + location.hash);
    }
    if (q) q.addEventListener("input", function () { state.q = q.value.trim(); apply(); });
    if (sort) sort.addEventListener("change", function () { state.sort = sort.value; apply(); });
    groups.forEach(function (g) { g.addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; state[g.getAttribute("data-group")] = b.getAttribute("data-value"); apply(); }); });
    var reset = $("[data-reset]", root);
    if (reset) reset.addEventListener("click", function () { state.q = ""; state.sort = "newest"; groups.forEach(function (g) { state[g.getAttribute("data-group")] = "all"; }); apply(); if (q) q.focus(); });
    apply();
  }
  $$("[data-filters]").forEach(initFilters);

  /* ---------- Site search ---------- */
  var TYPE_LABEL = { news: "News", update: "Update", rumor: "Rumor", question: "Question", guide: "Guide" };
  var BADGE = {
    news: { official: ["official", "Official source"], reported: ["reported", "Reported"], analysis: ["analysis", "Analysis"] },
    update: { official: ["official", "Official source"], reported: ["reported", "Reported"], scheduled: ["scheduled", "Scheduled"], website: ["website", "Website update"] },
    question: { confirmed: ["confirmed", "Official answer"], reported: ["reported", "Reported"], unconfirmed: ["unconfirmed", "Unconfirmed"], site: ["site", "About this site"] },
  };
  function badgeFor(it) {
    if (it.type === "rumor") return '<span class="badge badge--rumor">Rumor</span>';
    if (it.type === "guide") return it.label === "Speculative" ? '<span class="badge badge--speculation">Speculation</span>' : '<span class="badge badge--level">' + esc(it.label) + "</span>";
    var b = (BADGE[it.type] || {})[it.label]; return b ? '<span class="badge badge--' + b[0] + '">' + b[1] + "</span>" : "";
  }
  var indexPromise;
  function loadIndex() { return indexPromise || (indexPromise = fetch("/search-index.json").then(function (r) { if (!r.ok) throw new Error("index"); return r.json(); })); }
  function highlight(text, tokens) {
    var out = esc(text);
    tokens.forEach(function (t) { if (t.length < 2) return; out = out.replace(new RegExp("(" + t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "ig"), "<mark>$1</mark>"); });
    return out;
  }
  function resultHtml(it, tokens) {
    return '<li class="result"><div><div class="result__meta"><span class="tag">' + TYPE_LABEL[it.type] + "</span>" + badgeFor(it) + "<time datetime=\"" + esc(it.date) + '">' + fmtDate(it.date) + "</time></div>" +
      '<h3 class="result__title"><a href="' + esc(it.url) + '">' + highlight(it.title, tokens) + "</a></h3><p>" + highlight(it.summary, tokens) + "</p></div>" +
      '<div class="result__side"><button class="save" type="button" data-save="' + esc(it.id) + '" aria-pressed="false"><span class="save__label">Save</span><span class="sr-only"> “' + esc(it.title) + "” to watchlist</span></button></div></li>";
  }
  var searchRoot = $("[data-search-root]");
  if (searchRoot) {
    var qIn = $("[data-q]", searchRoot), resEl = $("[data-results]", searchRoot), cnt = $("[data-count]", searchRoot), emp = $("[data-empty]", searchRoot);
    var groups = $$(".chips[data-group]", searchRoot), st = { q: "", type: "all", tag: "all" }, params = new URLSearchParams(location.search);
    st.q = params.get("q") || ""; st.type = params.get("type") || "all"; st.tag = params.get("tag") || "all";
    loadIndex().then(function (idx) {
      function run() {
        var tokens = st.q.toLowerCase().split(/\s+/).filter(Boolean);
        var scored = idx.map(function (it) {
          if (st.type !== "all" && it.type !== st.type) return null;
          if (st.tag !== "all" && it.tags.indexOf(st.tag) < 0) return null;
          var title = it.title.toLowerCase(), sum = it.summary.toLowerCase(), tags = it.tags.join(" ").toLowerCase(), s = 0;
          for (var i = 0; i < tokens.length; i++) {
            var t = tokens[i], m = 0;
            if (title.indexOf(t) >= 0) m += 5; if (tags.indexOf(t) >= 0) m += 4; if (sum.indexOf(t) >= 0) m += 2; if (it.text && it.text.indexOf(t) >= 0) m += 1;
            if (!m) return null; s += m;
          }
          return { it: it, s: s };
        }).filter(Boolean).sort(function (a, b) { return b.s - a.s || (a.it.date < b.it.date ? 1 : -1); });
        resEl.innerHTML = scored.slice(0, 60).map(function (x) { return resultHtml(x.it, tokens); }).join("");
        var label = tokens.length ? scored.length + (scored.length === 1 ? " result" : " results") + " for “" + st.q + "”" : "Browsing all " + scored.length + " items, newest first";
        cnt.textContent = label + (scored.length > 60 ? " (showing the top 60)" : "");
        emp.hidden = scored.length !== 0;
        groups.forEach(function (g) { var n = g.getAttribute("data-group"); $$("button", g).forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-value") === st[n])); }); });
        if (qIn.value !== st.q) qIn.value = st.q;
        var p = new URLSearchParams(); if (st.q) p.set("q", st.q); if (st.type !== "all") p.set("type", st.type); if (st.tag !== "all") p.set("tag", st.tag);
        history.replaceState(null, "", location.pathname + (p.toString() ? "?" + p : ""));
        syncButtons(resEl);
      }
      qIn.addEventListener("input", function () { st.q = qIn.value.trim(); run(); });
      groups.forEach(function (g) { g.addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; st[g.getAttribute("data-group")] = b.getAttribute("data-value"); run(); }); });
      var rs = $("[data-reset]", searchRoot); rs.addEventListener("click", function () { st.q = ""; st.type = "all"; st.tag = "all"; run(); qIn.focus(); });
      searchRoot.querySelector("form").addEventListener("submit", function (e) { e.preventDefault(); st.q = qIn.value.trim(); run(); });
      run();
    }).catch(function () { cnt.textContent = "Search could not load its index. Please refresh, or browse the sections from the menu."; });
  }

  /* ---------- Watchlist page ---------- */
  var wlRoot = $("[data-watchlist-root]");
  if (wlRoot) {
    var wlList = $("[data-wl-list]", wlRoot), wlCount = $("[data-count]", wlRoot), wlEmpty = $("[data-empty]", wlRoot), clearBtn = $("[data-clear]", wlRoot), armed = false;
    loadIndex().then(function (idx) {
      var map = {}; idx.forEach(function (i) { map[i.id] = i; });
      function render() {
        var saved = readList();
        wlList.innerHTML = saved.map(function (s) {
          var it = map[s.id];
          if (!it) return '<li class="wl__item"><div><p class="result__title">This saved item is no longer available.</p><p class="muted">' + esc(s.id) + '</p></div><div class="wl__side"><button type="button" class="wl__remove" data-remove="' + esc(s.id) + '">Remove</button></div></li>';
          return '<li class="wl__item"><div><div class="result__meta"><span class="tag">' + TYPE_LABEL[it.type] + "</span>" + badgeFor(it) + '<time datetime="' + esc(it.date) + '">' + fmtDate(it.date) + '</time></div><h3 class="result__title"><a href="' + esc(it.url) + '">' + esc(it.title) + "</a></h3><p>" + esc(it.summary) + '</p></div><div class="wl__side"><button type="button" class="wl__remove" data-remove="' + esc(s.id) + '">Remove<span class="sr-only"> “' + esc(it.title) + "” from watchlist</span></button></div></li>";
        }).join("");
        wlCount.textContent = saved.length + (saved.length === 1 ? " saved item" : " saved items") + (storageOk ? "" : " (storage unavailable: items last only until you leave this page)");
        wlEmpty.hidden = saved.length !== 0; clearBtn.hidden = saved.length === 0; wlList.hidden = saved.length === 0;
        armed = false; clearBtn.textContent = "Clear all";
      }
      wlList.addEventListener("click", function (e) {
        var b = e.target.closest("[data-remove]"); if (!b) return;
        remove(b.getAttribute("data-remove")); toast("Removed from your watchlist.");
        var next = $(".wl__remove", wlList); if (next) next.focus(); else clearBtn.hidden || clearBtn.focus();
      });
      clearBtn.addEventListener("click", function () {
        if (!armed) { armed = true; clearBtn.textContent = "Confirm: remove all saved items"; return; }
        writeList([]); changed(); toast("Watchlist cleared.");
      });
      document.addEventListener("watchlist:change", render);
      render();
    }).catch(function () { wlCount.textContent = "The watchlist could not load. Please refresh the page."; });
  }

  /* ---------- Demo question form (no backend: nothing is sent or stored) ---------- */
  var form = $("#ask-form");
  if (form) {
    var topic = $("#ask-topic"), qEl = $("#ask-q"), tErr = $("#ask-topic-err"), qErr = $("#ask-q-err"), chars = $("[data-chars]", form), out = $("#ask-result");
    function show(el, input, msg) { el.textContent = msg; el.hidden = !msg; input.setAttribute("aria-invalid", msg ? "true" : "false"); }
    qEl.addEventListener("input", function () { chars.textContent = String(qEl.value.length); });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var text = qEl.value.trim().replace(/\s+/g, " "), bad = null;
      show(tErr, topic, topic.value ? "" : "Please choose a topic.");
      var m = ""; if (text.length < 10) m = "Please write at least 10 characters so the question is clear."; else if (text.length > 300) m = "Please keep it under 300 characters.";
      show(qErr, qEl, m);
      if (!topic.value) bad = topic; else if (m) bad = qEl;
      out.hidden = true;
      if (bad) { bad.focus(); return; }
      var label = topic.options[topic.selectedIndex].text, mailto = form.getAttribute("data-mailto");
      out.innerHTML = "<strong>Demo mode: your question was not sent, saved or published.</strong> This site has no database yet. Here is your draft:" +
        '<blockquote class="draft">' + esc(text) + "</blockquote><p class=\"muted\">Topic: " + esc(label) + '</p><div class="result__actions"><button type="button" class="btn btn--ghost" data-copy>Copy question</button>' +
        (mailto ? '<a class="btn btn--ghost" href="mailto:' + encodeURI(mailto) + "?subject=" + encodeURIComponent("Leonida Intel question: " + label) + "&body=" + encodeURIComponent(text) + '">Send by email</a>' : "") + "</div>";
      out.hidden = false; out.focus();
      $("[data-copy]", out).addEventListener("click", function () {
        var done = function () { toast("Question copied."); };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, function () { toast("Copy isn’t available in this browser."); });
        else toast("Copy isn’t available in this browser.");
      });
    });
  }

  /* ---------- Launch countdown ---------- */
  $$("[data-countdown]").forEach(function (el) {
    var p = el.getAttribute("data-date").split("-").map(Number), now = new Date();
    var days = Math.round((Date.UTC(p[0], p[1] - 1, p[2]) - Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
    var s = $("[data-countdown-text]");
    if (!s) return;
    s.textContent = days > 1 ? days + " days to go · as scheduled by Rockstar Games" : days === 1 ? "1 day to go · as scheduled by Rockstar Games" : days === 0 ? "The scheduled launch date is today. Check Rockstar’s official channels." : "The scheduled date has passed. Check Rockstar’s official channels for the latest.";
  });

  /* ---------- Timeline: keep "Upcoming" accurate relative to the visitor's date ---------- */
  $$(".tl__item[data-date]").forEach(function (li) {
    var up = li.getAttribute("data-date") > todayIso(), d = $(".tl__date", li), tag = $(".tl__tag", li);
    li.classList.toggle("is-upcoming", up);
    if (up && !tag) { tag = document.createElement("span"); tag.className = "tl__tag"; tag.textContent = "Upcoming"; d.appendChild(tag); }
    if (!up && tag) tag.remove();
    var sb = $(".badge--scheduled", li); if (sb && !up) sb.textContent = "Date reached";
  });

  /* ---------- Deep links to items on list pages (/updates#slug, /questions#slug) ---------- */
  function target() {
    if (!location.hash) return;
    var el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
    if (!el || !el.hasAttribute("data-item")) return;
    el.classList.remove("is-hidden"); if (el.tagName === "DETAILS") el.open = true;
    el.scrollIntoView({ block: "center" }); el.classList.remove("is-target"); void el.offsetWidth; el.classList.add("is-target");
  }
  window.addEventListener("hashchange", target); target();

  /* ---------- "/" jumps to search ---------- */
  document.addEventListener("keydown", function (e) {
    if (e.key !== "/" || e.ctrlKey || e.metaKey || e.altKey) return;
    var a = document.activeElement, tag = a && a.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (a && a.isContentEditable)) return;
    e.preventDefault();
    var f = $("[data-focus-key='/']"); if (f) f.focus(); else location.href = "/search";
  });
})();
