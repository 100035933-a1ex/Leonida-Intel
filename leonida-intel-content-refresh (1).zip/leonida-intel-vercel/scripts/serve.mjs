// Local preview server that mimics Vercel's cleanUrls behavior (/news -> dist/news.html) and 404 page.
// Usage: node scripts/serve.mjs [port]   (default 3000). Run `node build.mjs` first.
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { join, extname, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const dist = join(fileURLToPath(new URL("..", import.meta.url)), "dist");
const port = Number(process.argv[2] || process.env.PORT || 3000);
const types = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png", ".txt": "text/plain", ".xml": "application/xml" };
const exists = async (p) => { try { return (await stat(p)).isFile(); } catch { return false; } };

createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  let p = normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, "");
  if (p.endsWith(".html")) { res.writeHead(308, { Location: p.slice(0, -5).replace(/\/index$/, "/") || "/" }); return res.end(); }
  const candidates = p === "/" ? ["index.html"] : [p, p + ".html", join(p, "index.html")];
  let file = null;
  for (const c of candidates) if (await exists(join(dist, c))) { file = join(dist, c); break; }
  const status = file ? 200 : 404;
  if (!file) file = join(dist, "404.html");
  res.writeHead(status, { "Content-Type": types[extname(file)] || "application/octet-stream" });
  res.end(await readFile(file));
}).listen(port, () => console.log(`Preview: http://localhost:${port}  (Ctrl+C to stop)`));
