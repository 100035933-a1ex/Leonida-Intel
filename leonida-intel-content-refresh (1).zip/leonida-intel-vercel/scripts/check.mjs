// Post-build verification (no dependencies): internal links, assets, metadata, accessibility basics, honesty guards.
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const dist = join(dirname(fileURLToPath(import.meta.url)), "..", "dist");
if (!existsSync(dist)) { console.error("dist/ not found. Run `npm run build` first."); process.exit(1); }
const files = [];
(function walk(d) { for (const f of readdirSync(d)) { const p = join(d, f); statSync(p).isDirectory() ? walk(p) : files.push(p); } })(dist);
const html = files.filter((f) => f.endsWith(".html"));
const errors = [], warns = [];
const err = (m) => errors.push(m);

const resolves = (path) => {
  path = path.split("#")[0].split("?")[0];
  if (path === "" || path === "/") return true;
  const rel = path.replace(/^\//, "");
  return [rel, rel + ".html", join(rel, "index.html")].some((c) => existsSync(join(dist, c)) && statSync(join(dist, c)).isFile());
};
const NAV = ["/news", "/updates", "/rumors", "/questions", "/guides", "/membership"];

for (const f of html) {
  const name = f.slice(dist.length);
  const s = readFileSync(f, "utf8");
  const ids = new Set([...s.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
  if (!/<title>[^<]{5,}<\/title>/.test(s)) err(`${name}: missing <title>`);
  if (!/<meta name="description" content="[^"]{20,}"/.test(s)) err(`${name}: missing/short meta description`);
  if (!/property="og:title"/.test(s) || !/property="og:image"/.test(s) || !/name="twitter:card"/.test(s)) err(`${name}: missing social metadata`);
  if ((s.match(/<h1[\s>]/g) || []).length !== 1) err(`${name}: expected exactly one <h1>`);
  if (!/class="skip"/.test(s)) err(`${name}: missing skip link`);
  for (const n of NAV) if (!s.includes(`href="${n}"`)) err(`${name}: primary nav link ${n} missing`);
  if (/\sstyle="/.test(s)) err(`${name}: inline style attribute (blocked by CSP)`);
  if (/\son[a-z]+="/.test(s)) err(`${name}: inline event handler (blocked by CSP)`);
  for (const m of s.matchAll(/<img\b[^>]*>/g)) if (!/\salt=/.test(m[0])) err(`${name}: <img> without alt`);
  for (const m of s.matchAll(/\b(?:href|src)="([^"]+)"/g)) {
    const u = m[1].replace(/&amp;/g, "&");
    if (/^(https?:|mailto:|data:)/.test(u)) continue;
    if (u.startsWith("#")) { if (u.length > 1 && !ids.has(u.slice(1))) err(`${name}: broken in-page anchor ${u}`); continue; }
    if (!u.startsWith("/")) { err(`${name}: relative URL ${u}`); continue; }
    if (!resolves(u)) { err(`${name}: broken link ${u}`); continue; }
    const [path, hash] = u.split("#");
    if (hash && path && existsSync(join(dist, path.replace(/^\//, "") + ".html"))) {
      const t = readFileSync(join(dist, path.replace(/^\//, "") + ".html"), "utf8");
      if (!t.includes(`id="${hash}"`)) err(`${name}: ${u} points to a missing id`);
    }
  }
  for (const m of s.matchAll(/<a\b[^>]*target="_blank"[^>]*>/g)) if (!/rel="[^"]*noopener/.test(m[0])) err(`${name}: target=_blank without noopener`);
}

// Honesty guards on the membership page.
const mem = readFileSync(join(dist, "membership.html"), "utf8");
if (!/Planned, not available/.test(mem)) err("membership: missing 'Planned, not available' notice");
if (/<form/i.test(mem) || /checkout|credit card|subscribe now|buy now/i.test(mem.replace(/no checkout[^.]*\./gi, ""))) err("membership: contains checkout/purchase language or a form");
if (!/disabled/.test(mem)) err("membership: Intel Plus button should be disabled");

// Search index integrity.
const idx = JSON.parse(readFileSync(join(dist, "search-index.json"), "utf8"));
const seen = new Set();
for (const i of idx) { if (seen.has(i.id)) err(`search index: duplicate id ${i.id}`); seen.add(i.id); if (!resolves(i.url)) err(`search index: broken url ${i.url}`); }
for (const required of ["styles.css", "app.js", "robots.txt", "404.html", "assets/mark.svg", "assets/coastline.svg", "assets/og-image.png", "assets/apple-touch-icon.png"]) if (!existsSync(join(dist, required))) err(`missing ${required}`);
if (!/disclaimer|unofficial fan project/i.test(readFileSync(join(dist, "index.html"), "utf8"))) err("home: disclaimer missing");

console.log(`Checked ${html.length} HTML pages, ${idx.length} search entries.`);
warns.forEach((w) => console.warn("warn:", w));
if (errors.length) { console.error(`\n${errors.length} problem(s):\n- ` + errors.join("\n- ")); process.exit(1); }
console.log("All checks passed.");
