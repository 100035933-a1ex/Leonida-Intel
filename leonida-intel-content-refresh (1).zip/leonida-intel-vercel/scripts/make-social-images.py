"""Optional: regenerate public/assets/og-image.png (1200x630) and apple-touch-icon.png (180x180).
Needs Python + Playwright (pip install playwright && playwright install chromium). Output is committed."""
import pathlib
from playwright.sync_api import sync_playwright
root = pathlib.Path(__file__).resolve().parent.parent / "public" / "assets"
hero = (root / "coastline.svg").as_uri(); mark = (root / "mark.svg").as_uri()
og = f"""<html><body style="margin:0;width:1200px;height:630px;position:relative;background:#0a1220;font-family:system-ui,Segoe UI,Arial,sans-serif;color:#eaf2f8;overflow:hidden">
<img src="{hero}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover">
<div style="position:absolute;inset:0;background:linear-gradient(90deg,rgba(10,18,32,.96),rgba(10,18,32,.7) 55%,rgba(10,18,32,.15))"></div>
<div style="position:absolute;left:72px;top:64px;display:flex;align-items:center;gap:16px"><img src="{mark}" width="64" height="64"><div style="font-weight:700;letter-spacing:.14em;font-size:26px">LEONIDA <span style="font-weight:400;color:#4cc3e8">INTEL</span></div></div>
<div style="position:absolute;left:72px;top:210px;width:760px"><div style="font:600 18px ui-monospace,Menlo,monospace;letter-spacing:.16em;color:#4cc3e8;margin-bottom:22px">UNOFFICIAL INTELLIGENCE DESK · GTA 6</div>
<div style="font-size:78px;line-height:1;font-weight:750;letter-spacing:-.04em">Know what's confirmed.<br><span style="color:#4cc3e8">Track what isn't.</span></div></div>
<div style="position:absolute;left:72px;bottom:48px;font:500 18px ui-monospace,Menlo,monospace;color:#9db0c2">Independent fan project · Not affiliated with Rockstar Games or Take-Two</div></body></html>"""
icon = f"""<html><body style="margin:0"><img src="{mark}" width="180" height="180" style="display:block"></body></html>"""
with sync_playwright() as p:
    b = p.chromium.launch()
    for html, size, name in [(og, (1200, 630), "og-image.png"), (icon, (180, 180), "apple-touch-icon.png")]:
        pg = b.new_page(viewport={"width": size[0], "height": size[1]}); pg.set_content(html); pg.wait_for_timeout(300)
        pg.screenshot(path=str(root / name)); pg.close()
    b.close()
print("wrote og-image.png and apple-touch-icon.png")
