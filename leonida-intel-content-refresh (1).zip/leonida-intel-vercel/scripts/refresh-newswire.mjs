// Refresh candidate inbox from Rockstar's official Newswire archive.
// This deliberately does NOT publish new stories automatically: a human must verify each candidate.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { NEWS } from '../src/content/news.mjs';
import { UPDATES } from '../src/content/updates.mjs';
import { RUMORS } from '../src/content/rumors.mjs';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const archiveUrl = 'https://www.rockstargames.com/newswire?tag=vi';
const outputPath = join(root, 'content-refresh', 'rockstar-newswire-inbox.json');
const headers = { 'user-agent': 'LeonidaIntelContentRefresh/1.0 (+manual editorial review)', 'accept': 'text/html,application/xhtml+xml' };

function decodeEntities(s) {
  return s.replace(/&amp;/g, '&').replace(/&#x27;|&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ');
}
function stripTags(s) { return decodeEntities(s.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()); }
function knownUrls() {
  const urls = new Set();
  for (const item of [...NEWS, ...UPDATES, ...RUMORS]) {
    for (const source of [item.source, ...(item.sources || [])]) if (source?.url) urls.add(source.url.replace(/\/$/, ''));
  }
  return urls;
}

let response;
try {
  response = await fetch(archiveUrl, { headers, signal: AbortSignal.timeout(25000) });
} catch (error) {
  throw new Error(`Could not reach Rockstar Newswire; existing editorial inbox was left untouched. Retry later. Details: ${error.message}`);
}
if (!response.ok) throw new Error(`Rockstar Newswire returned HTTP ${response.status}; existing editorial inbox was left untouched.`);
const html = await response.text();
if (!/newswire/i.test(html) || html.length < 5000) throw new Error('Newswire response looked incomplete; inbox was not changed.');
const known = knownUrls();
const seen = new Set();
const candidates = [];
const anchorRe = /<a\b[^>]*href=["']([^"']*\/newswire\/article\/[^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
let match;
while ((match = anchorRe.exec(html))) {
  const href = decodeEntities(match[1]);
  const url = new URL(href, 'https://www.rockstargames.com').href;
  if (!/rockstargames\.com\/newswire\/article\//i.test(url) || seen.has(url)) continue;
  seen.add(url);
  const around = html.slice(Math.max(0, match.index - 900), Math.min(html.length, anchorRe.lastIndex + 1400));
  const title = stripTags(match[2]);
  const context = stripTags(around);
  if (!/grand theft auto vi|\bGTA VI\b/i.test(`${title} ${context}`)) continue;
  const dateMatch = context.match(/\b(20\d{2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2})\b/i)
    || context.match(/\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),?\s+(20\d{2})\b/i);
  let date = null;
  if (dateMatch) {
    const d = dateMatch[1].match(/^20/) ? new Date(`${dateMatch[1]} ${dateMatch[2]} ${dateMatch[3]} UTC`) : new Date(`${dateMatch[1]} ${dateMatch[2]} ${dateMatch[3]} UTC`);
    if (!Number.isNaN(d.valueOf())) date = d.toISOString().slice(0, 10);
  }
  if (!known.has(url)) candidates.push({ title: title || 'Review title on source page', url, date, source: 'Rockstar Games Newswire', status: 'needs-editorial-review', note: 'Candidate discovered automatically. Verify the article and add a human-written summary before publishing.' });
}

const previous = (() => { try { return JSON.parse(readFileSync(outputPath, 'utf8')); } catch { return { candidates: [] }; } })();
const old = new Map((previous.candidates || []).map(x => [x.url, x]));
for (const item of candidates) old.set(item.url, { ...old.get(item.url), ...item, firstSeen: old.get(item.url)?.firstSeen || new Date().toISOString() });
const payload = {
  generatedAt: new Date().toISOString(),
  archiveUrl,
  policy: 'Discovery only. New items are never published automatically; editor verification and a human-written summary are required.',
  checkedLinks: seen.size,
  candidates: [...old.values()].sort((a, b) => (b.date || '').localeCompare(a.date || '')),
};
mkdirSync(dirname(outputPath), { recursive: true });
writeFileSync(outputPath, JSON.stringify(payload, null, 2) + '\n');
console.log(`Checked ${seen.size} Newswire article links; ${candidates.length} newly discovered candidate(s); ${payload.candidates.length} total in editorial inbox.`);
