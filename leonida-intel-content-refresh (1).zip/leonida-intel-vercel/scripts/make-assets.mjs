// Generates the original SVG artwork in public/assets (hero, atlas, brand mark).
// Run: node scripts/make-assets.mjs   (output is committed; re-run only to change the art)
import { writeFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const out = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "assets");
mkdirSync(out, { recursive: true });

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- Brand mark ----------
writeFileSync(join(out, "mark.svg"), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0f2236"/><stop offset="1" stop-color="#08101c"/></linearGradient></defs>
<rect width="64" height="64" rx="12" fill="url(#g)"/>
<rect x="6.5" y="6.5" width="51" height="51" rx="8" fill="none" stroke="#4cc3e8" stroke-opacity=".55"/>
<path d="M20 16v26h14" fill="none" stroke="#e8f4fa" stroke-width="4.5" stroke-linecap="square"/>
<path d="M40 22v20" fill="none" stroke="#4cc3e8" stroke-width="4.5" stroke-linecap="square"/>
<circle cx="40" cy="15.5" r="3" fill="#4cc3e8"/>
<path d="M14 49h36" stroke="#4cc3e8" stroke-opacity=".5" stroke-width="2"/>
</svg>
`);

// ---------- Hero: original coastal city at dusk ----------
function palm(x, base, h, lean, scale, r) {
  const topX = x + lean, topY = base - h;
  let s = `<path d="M${x} ${base} Q${x + lean * 0.15} ${base - h * 0.55} ${topX} ${topY}" stroke="#04080f" stroke-width="${7 * scale}" fill="none" stroke-linecap="round"/>`;
  const angles = [-160, -128, -96, -64, -32, -8, 14, 36];
  for (const a of angles) {
    const rad = (a * Math.PI) / 180;
    const len = (120 + r() * 50) * scale;
    const ex = topX + Math.cos(rad) * len;
    const ey = topY + Math.sin(rad) * len * 0.55 + len * 0.42;
    const mx = topX + Math.cos(rad) * len * 0.5;
    const my = topY + Math.sin(rad) * len * 0.5 - 26 * scale;
    s += `<path d="M${topX} ${topY} Q${mx} ${my - 8 * scale} ${ex} ${ey} Q${mx} ${my + 14 * scale} ${topX} ${topY}Z" fill="#04080f"/>`;
  }
  return s;
}

function skyline(r, x0, x1, baseY, minH, maxH, fill, lights) {
  let s = "", windows = "", x = x0;
  while (x < x1) {
    const w = 26 + r() * 54, h = minH + r() * (maxH - minH);
    s += `<rect x="${x.toFixed(1)}" y="${(baseY - h).toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" fill="${fill}"/>`;
    if (r() > 0.72) s += `<rect x="${(x + w * 0.45).toFixed(1)}" y="${(baseY - h - 22).toFixed(1)}" width="3" height="22" fill="${fill}"/>`;
    if (lights) {
      for (let i = 0; i < Math.floor(w / 9); i++) for (let j = 0; j < Math.floor(h / 18); j++) {
        if (r() > 0.86) windows += `<rect x="${(x + 5 + i * 9).toFixed(1)}" y="${(baseY - h + 8 + j * 18).toFixed(1)}" width="3" height="5" fill="#8fdcf5" opacity="${(0.35 + r() * 0.5).toFixed(2)}"/>`;
      }
    }
    x += w + 3 + r() * 8;
  }
  return s + windows;
}

(function hero() {
  const r = rng(2026);
  let stars = "";
  for (let i = 0; i < 70; i++) stars += `<circle cx="${(r() * 1600).toFixed(0)}" cy="${(r() * 380).toFixed(0)}" r="${(0.6 + r() * 1.1).toFixed(1)}" fill="#cfeaf6" opacity="${(0.2 + r() * 0.5).toFixed(2)}"/>`;
  let streaks = "";
  for (let i = 0; i < 26; i++) {
    const y = 720 + i * 11 + r() * 6, w = 40 + r() * 220, x = 780 + (r() - 0.5) * 520;
    streaks += `<rect x="${(x - w / 2).toFixed(0)}" y="${y.toFixed(0)}" width="${w.toFixed(0)}" height="2" fill="#7fd6f2" opacity="${(0.05 + r() * 0.14).toFixed(2)}"/>`;
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1000" preserveAspectRatio="xMidYMid slice">
<defs>
<linearGradient id="sky" x2="0" y2="1"><stop offset="0" stop-color="#050912"/><stop offset=".42" stop-color="#0b1c2e"/><stop offset=".7" stop-color="#14465c"/><stop offset="1" stop-color="#2a8aa3"/></linearGradient>
<radialGradient id="sun" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#e9fbff" stop-opacity=".95"/><stop offset=".18" stop-color="#9fe6f7" stop-opacity=".55"/><stop offset="1" stop-color="#4cc3e8" stop-opacity="0"/></radialGradient>
<linearGradient id="sea" x2="0" y2="1"><stop offset="0" stop-color="#16556b"/><stop offset=".35" stop-color="#0c2a3d"/><stop offset="1" stop-color="#050b14"/></linearGradient>
<linearGradient id="haze" x2="0" y2="1"><stop offset="0" stop-color="#4cc3e8" stop-opacity="0"/><stop offset="1" stop-color="#4cc3e8" stop-opacity=".22"/></linearGradient>
</defs>
<rect width="1600" height="1000" fill="url(#sky)"/>${stars}
<circle cx="1090" cy="640" r="420" fill="url(#sun)"/>
<circle cx="1090" cy="650" r="62" fill="#e6faff" opacity=".92"/>
<g opacity=".55"><path d="M0 640H1600" stroke="#9fe6f7" stroke-opacity=".25"/></g>
<path d="M0 676 150 640 300 662 470 612 650 650 820 600 1010 646 1190 596 1380 640 1600 614V740H0Z" fill="#12394d"/>
<g fill="none"><rect x="0" y="560" width="1600" height="120" fill="url(#haze)"/></g>
<g>${skyline(r, 70, 700, 700, 50, 190, "#0a1b2a", true)}</g>
<g>${skyline(r, 900, 1560, 700, 40, 270, "#08141f", true)}</g>
<path d="M0 700H1600V1000H0Z" fill="url(#sea)"/>
${streaks}
<path d="M0 760Q260 735 520 765T1040 750T1600 765" fill="none" stroke="#7fd6f2" stroke-opacity=".18" stroke-width="2"/>
<path d="M0 840Q300 815 600 845T1200 835T1600 848" fill="none" stroke="#7fd6f2" stroke-opacity=".12" stroke-width="2"/>
<path d="M0 930Q320 905 640 935T1280 925T1600 938" fill="none" stroke="#7fd6f2" stroke-opacity=".1" stroke-width="2"/>
<g>${palm(1430, 1000, 470, -50, 1.25, r)}${palm(1290, 1000, 360, -24, 0.95, r)}${palm(110, 1000, 330, 36, 0.9, r)}</g>
<rect y="960" width="1600" height="40" fill="#04080f"/>
</svg>
`;
  writeFileSync(join(out, "coastline.svg"), svg);
})();

// ---------- Atlas: abstract topographic terrain study ----------
(function atlas() {
  let lines = "";
  for (let i = 0; i < 22; i++) {
    const y = 60 + i * 38;
    lines += `<path d="M-60 ${y}Q150 ${y - 60 + (i % 3) * 20} 300 ${y + 18}T620 ${y - 6}T960 ${y + 38}T1280 ${y - 10}" stroke-opacity="${(0.18 + (i % 5) * 0.07).toFixed(2)}"/>`;
  }
  writeFileSync(join(out, "atlas.svg"), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900" preserveAspectRatio="xMidYMid slice">
<defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="#12304a"/><stop offset="1" stop-color="#070d17"/></linearGradient></defs>
<rect width="1200" height="900" fill="url(#bg)"/>
<g fill="none" stroke="#4cc3e8" stroke-width="1.6">${lines}</g>
<path d="M-30 800Q180 650 320 700T600 560T840 480T1040 300T1240 170" stroke="#e8f4fa" stroke-width="3.5" fill="none" stroke-dasharray="2 10" stroke-linecap="round"/>
<g fill="#08101c" stroke="#4cc3e8" stroke-width="2"><circle cx="320" cy="700" r="9"/><circle cx="600" cy="560" r="9"/><circle cx="840" cy="480" r="9"/><circle cx="1040" cy="300" r="9"/></g>
<g fill="#8fdcf5" font-family="ui-monospace,Menlo,Consolas,monospace" font-size="17" letter-spacing="3"><text x="64" y="70">ORIGINAL TERRAIN STUDY</text><text x="800" y="850">FIELD FILE 001</text></g>
</svg>
`);
})();

console.log("Wrote mark.svg, coastline.svg, atlas.svg to", out);
