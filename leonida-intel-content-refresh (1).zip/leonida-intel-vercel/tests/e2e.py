"""End-to-end browser tests. Optional dev tool (not needed to deploy).
Setup:  pip install playwright && playwright install chromium
Run:    node build.mjs && python tests/e2e.py
Starts scripts/serve.mjs (which emulates Vercel cleanUrls + 404) and drives headless Chromium."""
import subprocess, sys, time, pathlib, re
from playwright.sync_api import sync_playwright, expect

ROOT = pathlib.Path(__file__).resolve().parent.parent
PORT = 4173
BASE = f"http://localhost:{PORT}"
results = []

def check(name, fn):
    try:
        fn(); results.append((True, name)); print("PASS", name)
    except Exception as e:
        results.append((False, name)); print("FAIL", name, "->", (str(e).splitlines() or [repr(e)])[0][:200])

server = subprocess.Popen(["node", "scripts/serve.mjs", str(PORT)], cwd=ROOT, stdout=subprocess.DEVNULL)
time.sleep(1.2)
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1280, "height": 900})
        page = ctx.new_page()
        console_errors = []
        page.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: console_errors.append(str(e)))
        page.on("requestfailed", lambda r: console_errors.append("requestfailed " + r.url) if "ERR_ABORTED" not in (r.failure or "") else None)

        # --- Six primary sections: click through the nav, check URL, heading, refresh, back ---
        sections = [("News", "/news"), ("Updates", "/updates"), ("Rumors", "/rumors"), ("Questions", "/questions"), ("Guides", "/guides"), ("Membership", "/membership")]
        page.goto(BASE + "/")
        for label, path in sections:
            def nav_test(label=label, path=path):
                page.goto(BASE + "/")
                page.locator("#site-nav .nav__link", has_text=label).click()
                page.wait_for_url("**" + path)
                assert page.locator("h1").count() == 1
                page.reload(); assert page.url.endswith(path)
                assert page.locator(f'#site-nav a[aria-current="page"]').count() == 1
                page.go_back(); page.wait_for_url(BASE + "/")
            check(f"nav: {label} opens {path}, survives refresh and back", nav_test)

        def direct_deep():
            for path in ["/news/pricing-editions-preload-dates", "/rumors/pc-version-q1-2027", "/guides/leonida-explained", "/updates#launch-trailer", "/questions#is-there-a-pc-version"]:
                r = page.goto(BASE + path); assert r.status == 200, path
        check("direct navigation to deep URLs returns 200", direct_deep)

        def not_found():
            r = page.goto(BASE + "/nope"); assert r.status == 404
            assert "isn’t on the map" in page.content()
            console_errors.clear()  # the browser logs the intentional 404 as a console error
        check("unknown URL shows 404 page", not_found)

        # --- Dashboard ---
        def dashboard():
            page.goto(BASE + "/")
            for h in ["Today’s briefing", "What Rockstar has said", "Recently discussed, never confirmed as fact", "Start here", "Six sections, one briefing"]:
                assert page.get_by_role("heading", name=h).count() == 1, h
            assert page.locator(".tile").count() == 6
            assert page.locator("[data-countdown-text]").inner_text().strip() != ""
            assert page.locator(".log li").count() >= 5
        check("dashboard panels and six quick links render", dashboard)

        # --- News: search, filter, sort, related, article page ---
        def news_filters():
            page.goto(BASE + "/news")
            total = page.locator("#main [data-item]").count(); assert total == 8
            page.fill("[data-q]", "radio"); assert page.locator("#main [data-item]:not(.is-hidden)").count() >= 1
            page.fill("[data-q]", "zzzzqq"); expect(page.locator("[data-empty]")).to_be_visible()
            page.click("[data-reset]"); assert page.locator("#main [data-item]:not(.is-hidden)").count() == total
            page.get_by_role("button", name="Music", exact=True).click()
            assert page.locator("#main [data-item]:not(.is-hidden)").count() == 2
            page.get_by_role("button", name="All", exact=True).click()
            page.select_option("[data-sort]", "oldest")
            first = page.locator("#main [data-item]").first.get_attribute("data-date")
            assert first == "2026-06-18" or first <= "2026-08-27", first
            page.select_option("[data-sort]", "newest")
            assert page.locator("#main [data-item]").first.get_attribute("data-date") == "2026-10-18"
        check("news: search, empty state, category filter, sort", news_filters)

        def article():
            page.goto(BASE + "/news/launch-trailer-justice-score")
            assert page.locator(".badge--official").count() >= 1
            assert page.locator(".sources a[target=_blank]").count() >= 1
            assert page.get_by_role("heading", name="Related articles").count() == 1
            page.goto(BASE + "/news/analysis-gta-online-what-is-confirmed")
            assert page.locator(".badge--analysis").count() >= 1
        check("news article: labels, sources, related articles", article)

        # --- Updates ---
        def updates():
            page.goto(BASE + "/updates")
            assert page.locator(".tl__item").count() == 13
            assert page.locator(".tl__item time").count() == 13
            page.get_by_role("button", name="Website updates").click()
            assert page.locator(".tl__item:not(.is-hidden)").count() == 1
            page.get_by_role("button", name="Official announcements").click()
            assert page.locator(".tl__item:not(.is-hidden)").count() >= 8
            page.goto(BASE + "/updates#launch-trailer")
            assert "is-target" in page.locator("#launch-trailer").get_attribute("class")
        check("updates: timeline dates, filters, deep link highlight", updates)

        # --- Rumors ---
        def rumors():
            page.goto(BASE + "/rumors")
            assert page.locator(".card--rumor").count() == 7
            assert page.locator(".card--rumor .badge--rumor").count() == 7
            page.get_by_role("button", name="Platforms", exact=True).click()
            assert page.locator(".card--rumor:not(.is-hidden)").count() == 1
            page.get_by_role("button", name="All", exact=True).first.click()
            page.get_by_role("button", name="Resolved", exact=True).click()
            assert page.locator(".card--rumor:not(.is-hidden)").count() == 2
            page.goto(BASE + "/rumors/pc-version-q1-2027")
            for t in ["Rumor: not confirmed.", "What is known", "What remains unconfirmed", "Our confidence label"]:
                assert t in page.content(), t
        check("rumors: labels, topic/status filters, detail page", rumors)

        # --- Questions ---
        def questions():
            page.goto(BASE + "/questions")
            n = page.locator(".qa").count(); assert n == 16
            page.fill("[data-q]", "preload"); assert page.locator(".qa:not(.is-hidden)").count() >= 1
            page.fill("[data-q]", ""); page.get_by_role("button", name="Vehicles").click()
            assert page.locator(".qa:not(.is-hidden)").count() == 1
            page.get_by_role("button", name="All", exact=True).click()
            # form validation
            page.get_by_role("button", name="Check my question").click()
            expect(page.locator("#ask-topic-err")).to_be_visible(); expect(page.locator("#ask-q-err")).to_be_visible()
            page.select_option("#ask-topic", "map"); page.fill("#ask-q", "short"); page.get_by_role("button", name="Check my question").click()
            expect(page.locator("#ask-q-err")).to_contain_text("at least 10")
            page.fill("#ask-q", "Will the map change after launch?"); page.get_by_role("button", name="Check my question").click()
            res = page.locator("#ask-result"); expect(res).to_be_visible()
            expect(res).to_contain_text("not sent, saved or published")
        check("questions: search, topic filter, form validation, honest demo result", questions)

        # --- Guides ---
        def guides():
            page.goto(BASE + "/guides")
            assert page.locator(".card--guide").count() == 8
            page.get_by_role("button", name="Speculative", exact=True).click()
            assert page.locator(".card--guide:not(.is-hidden)").count() == 1
            page.get_by_role("button", name="All", exact=True).first.click()
            page.fill("[data-q]", "weather"); assert page.locator(".card--guide:not(.is-hidden)").count() >= 1
            page.goto(BASE + "/guides/speculation-how-might-online-work")
            assert "SPECULATIVE GUIDE" in page.content() and page.locator(".badge--speculation").count() >= 1
            page.goto(BASE + "/guides/leonida-explained")
            assert page.get_by_role("heading", name="Related guides").count() == 1
        check("guides: type filter, search, speculative label, related guides", guides)

        # --- Membership honesty ---
        def membership():
            page.goto(BASE + "/membership")
            assert "Planned, not available" in page.content()
            btn = page.get_by_role("button", name="Not on sale yet"); expect(btn).to_be_disabled()
            assert page.locator("form").count() == 0
            assert page.locator("text=/proposal|proposed/i").count() >= 2
            assert page.locator("table.compare").count() == 1
        check("membership: planned-only, disabled button, no checkout/form", membership)

        # --- Site-wide search ---
        def search():
            page.goto(BASE + "/search")
            expect(page.locator(".result").first).to_be_visible()
            page.fill("#search-q", "pc"); page.wait_for_function("document.querySelectorAll('.result').length >= 2 && document.querySelector('[data-count]').textContent.includes('for')")
            page.get_by_role("button", name="Rumors", exact=True).click()
            page.wait_for_function("[...document.querySelectorAll('.result .tag')].length > 0 && [...document.querySelectorAll('.result .tag')].every(e => e.textContent === 'Rumor')")
            page.get_by_role("button", name="All", exact=True).first.click()
            page.fill("#search-q", "qqqzzz"); expect(page.locator("[data-empty]")).to_be_visible()
            page.goto(BASE + "/search?q=radio&type=guide")
            expect(page.locator(".result").first).to_be_visible()
            page.goto(BASE + "/"); page.fill("#hero-q", "price"); page.keyboard.press("Enter"); page.wait_for_url("**/search?q=price")
            page.wait_for_function("document.querySelectorAll('.result').length >= 2")
        check("search: all types, type filter, empty state, URL params, hero form", search)

        # --- Watchlist ---
        def watchlist():
            page.goto(BASE + "/watchlist"); expect(page.locator("[data-empty]")).to_be_visible()
            page.goto(BASE + "/news")
            page.locator("#main .save").first.click()
            expect(page.locator("#toast")).to_contain_text("Saved"); 
            expect(page.locator("[data-watch-count]").first).to_have_text("1")
            page.goto(BASE + "/rumors/pc-version-q1-2027"); page.locator(".article__actions .save").click()
            page.goto(BASE + "/guides"); page.locator("#main .save").first.click()
            page.goto(BASE + "/updates"); page.locator("#main .save").first.click()
            page.goto(BASE + "/watchlist")
            expect(page.locator(".wl__item")).to_have_count(4)
            page.reload(); expect(page.locator(".wl__item")).to_have_count(4)   # persists across refresh
            page.locator(".wl__remove").first.click(); expect(page.locator(".wl__item")).to_have_count(3)
            page.goto(BASE + "/news"); expect(page.locator("[data-watch-count]").first).to_have_text("3")
            assert page.locator("#main .save[aria-pressed=true]").count() >= 0
            page.goto(BASE + "/watchlist")
            page.get_by_role("button", name="Clear all").click(); page.get_by_role("button", name="Confirm: remove all saved items").click()
            expect(page.locator("[data-empty]")).to_be_visible()
            assert "this device only" in page.content().lower() or "stored on this device" in page.content().lower()
        check("watchlist: save, count, persist, remove, clear, honest device-only note", watchlist)

        def about():
            page.goto(BASE + "/about"); assert "Unofficial fan project" in page.content()
        check("about page and disclaimer", about)

        # --- Keyboard & a11y basics ---
        def keyboard():
            page.goto(BASE + "/"); page.keyboard.press("Tab")
            assert page.evaluate("document.activeElement.className") == "skip"
            page.keyboard.press("Enter"); assert page.evaluate("location.hash") == "#main"
            page.keyboard.press("/") ; 
            assert page.evaluate("document.activeElement.id") == "hero-q"
        check("keyboard: skip link works, '/' focuses search", keyboard)

        check("no console errors / CSP violations / failed requests on desktop", lambda: (_ for _ in ()).throw(AssertionError(console_errors[:3])) if console_errors else None)

        # --- Mobile ---
        m = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        mp = m.new_page(); merrs = []
        mp.on("console", lambda x: merrs.append(x.text) if x.type == "error" else None)
        mp.on("pageerror", lambda e: merrs.append(str(e)))

        def mobile_nav():
            mp.goto(BASE + "/")
            expect(mp.locator("#site-nav")).to_be_hidden()
            mp.locator(".nav-toggle").click(); expect(mp.locator("#site-nav")).to_be_visible()
            assert mp.locator(".nav-toggle").get_attribute("aria-expanded") == "true"
            for label in ["News", "Updates", "Rumors", "Questions", "Guides", "Membership"]:
                expect(mp.locator("#site-nav .nav__link", has_text=label)).to_be_visible()
            mp.keyboard.press("Escape"); expect(mp.locator("#site-nav")).to_be_hidden()
            mp.locator(".nav-toggle").click(); mp.locator("#site-nav .nav__link", has_text="Guides").click()
            mp.wait_for_url("**/guides"); expect(mp.locator("#site-nav")).to_be_hidden()
        check("mobile: collapsible menu exposes all six sections", mobile_nav)

        def no_overflow():
            for path in ["/", "/news", "/news/pricing-editions-preload-dates", "/updates", "/rumors", "/rumors/pc-version-q1-2027", "/questions", "/guides", "/membership", "/search", "/watchlist", "/about"]:
                mp.goto(BASE + path)
                sw = mp.evaluate("document.documentElement.scrollWidth"); assert sw <= 391, (path, sw)
        check("mobile: no horizontal overflow on any page", no_overflow)

        def mobile_save():
            mp.goto(BASE + "/news"); mp.locator("#main .save").first.click()
            expect(mp.locator("#toast")).to_contain_text("Saved")
        check("mobile: save + toast", mobile_save)
        check("no console errors on mobile", lambda: (_ for _ in ()).throw(AssertionError(merrs[:3])) if merrs else None)

        # Screenshots for visual review
        outdir = pathlib.Path("/tmp/shots"); outdir.mkdir(exist_ok=True)
        for name, path in [("home", "/"), ("news", "/news"), ("updates", "/updates"), ("rumors", "/rumors"), ("membership", "/membership"), ("article", "/news/pricing-editions-preload-dates"), ("search", "/search?q=pc")]:
            page.goto(BASE + path); page.wait_for_timeout(250); page.screenshot(path=str(outdir / f"d-{name}.png"), full_page=(name != "home"))
        for name, path in [("home", "/"), ("rumors", "/rumors")]:
            mp.goto(BASE + path); mp.wait_for_timeout(250); mp.screenshot(path=str(outdir / f"m-{name}.png"))
        b.close()
finally:
    server.terminate()

failed = [n for ok, n in results if not ok]
print(f"\n{len(results) - len(failed)}/{len(results)} passed")
sys.exit(1 if failed else 0)
