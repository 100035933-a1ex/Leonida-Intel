// Site-wide configuration. Nothing secret lives here.
// Optional build-time environment variables (set in Vercel > Settings > Environment Variables):
//   SITE_URL       e.g. https://leonidaintel.com  (used for canonical URLs, sitemap, social images)
//   CONTACT_EMAIL  e.g. tips@example.com          (enables optional "send by email" links; never required)

function resolveBase() {
  const raw = process.env.SITE_URL || process.env.VERCEL_PROJECT_PRODUCTION_URL || "";
  if (!raw) return "";
  const withProto = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
  return withProto.replace(/\/+$/, "");
}

export const SITE = {
  name: "Leonida Intel",
  tagline: "Independent GTA 6 intelligence",
  description:
    "Leonida Intel is an unofficial, independent GTA 6 information site: sourced news, dated updates, clearly labeled rumors, community questions and practical guides.",
  baseUrl: resolveBase(),
  contactEmail: process.env.CONTACT_EMAIL || "",
  // Release date as scheduled by Rockstar Games (see /updates). Update here if it ever changes.
  releaseDate: "2026-11-19",
  lastReviewed: "2026-10-18",
  disclaimer:
    "Leonida Intel is an unofficial fan project. It is not affiliated with, endorsed by, or sponsored by Rockstar Games or Take-Two Interactive. Grand Theft Auto and related names and marks belong to their respective owners.",
};

// The six primary sections. Order = navigation order.
export const NAV = [
  { key: "news", label: "News", href: "/news", blurb: "Sourced reporting and analysis, clearly labeled." },
  { key: "updates", label: "Updates", href: "/updates", blurb: "A dated timeline of official developments." },
  { key: "rumors", label: "Rumors", href: "/rumors", blurb: "Leaks and speculation, never presented as fact." },
  { key: "questions", label: "Questions", href: "/questions", blurb: "Searchable answers and a place to ask." },
  { key: "guides", label: "Guides", href: "/guides", blurb: "Practical explainers for new and returning players." },
  { key: "membership", label: "Membership Plans", short: "Membership", href: "/membership", blurb: "The free experience and the proposed Intel Plus plan." },
];
