// Procedural, original card artwork. Each item gets a unique-looking SVG derived from its slug.
// No third-party or game imagery is used anywhere.
import { hashString, rng } from "./util.mjs";

const PALETTES = {
  release: ["#0b1b2e", "#14516b", "#8fdcf5"],
  media: ["#0a1426", "#1d3b66", "#7fb4ff"],
  music: ["#0d1426", "#2a2f6b", "#a9b8ff"],
  features: ["#08171f", "#14584f", "#7fe3cf"],
  pricing: ["#0c1a26", "#1c4f6e", "#9fe0ff"],
  analysis: ["#101426", "#3a3470", "#c3b8ff"],
  rumor: ["#1a1410", "#5a3a14", "#ffc46b"],
  guide: ["#09192a", "#164c63", "#79d6ef"],
  update: ["#0a1626", "#1a4666", "#8fd4f5"],
};

export function artKind(type, category = "") {
  const c = category.toLowerCase();
  if (type === "rumor") return "rumor";
  if (type === "guide") return "guide";
  if (type === "update") return "update";
  if (type === "question") return "guide";
  if (c.includes("music")) return "music";
  if (c.includes("trailer")) return "media";
  if (c.includes("feature")) return "features";
  if (c.includes("price") || c.includes("edition")) return "pricing";
  if (c.includes("analysis")) return "analysis";
  return "release";
}

export function cardArt(slug, kind) {
  const [c0, c1, ac] = PALETTES[kind] || PALETTES.release;
  const r = rng(hashString(slug + kind));
  const W = 640, H = 360;
  let motif = "";
  const line = `stroke="${ac}" fill="none"`;

  if (kind === "music") {
    const bars = 46;
    for (let i = 0; i < bars; i++) {
      const h = 18 + Math.abs(Math.sin(i * 0.42 + r() * 1.6)) * 150 * (0.4 + r() * 0.7);
      motif += `<rect x="${40 + i * 12.6}" y="${(H / 2 - h / 2).toFixed(1)}" width="6" height="${h.toFixed(1)}" rx="3" fill="${ac}" opacity="${(0.25 + r() * 0.55).toFixed(2)}"/>`;
    }
  } else if (kind === "rumor") {
    for (let i = 1; i <= 5; i++) motif += `<circle cx="${W * 0.62}" cy="${H * 0.56}" r="${i * 48}" ${line} stroke-opacity="${(0.55 - i * 0.08).toFixed(2)}" stroke-dasharray="${i % 2 ? "2 7" : "none"}"/>`;
    motif += `<path d="M${W * 0.62} ${H * 0.56} L${W * 0.62 + 240} ${H * 0.56 - 90}" ${line} stroke-width="2" stroke-opacity=".5"/>`;
    for (let i = 0; i < 7; i++) motif += `<circle cx="${(W * 0.62 + (r() - 0.5) * 420).toFixed(0)}" cy="${(H * 0.56 + (r() - 0.5) * 240).toFixed(0)}" r="${(3 + r() * 4).toFixed(1)}" fill="${ac}" opacity="${(0.4 + r() * 0.5).toFixed(2)}"/>`;
  } else if (kind === "features" || kind === "guide") {
    for (let i = 0; i < 14; i++) {
      const y = 30 + i * 24;
      motif += `<path d="M-20 ${y}Q${120 + r() * 80} ${y - 40 + r() * 30} ${260 + r() * 60} ${y + 8}T${520 + r() * 60} ${y - 4}T700 ${y + 12}" ${line} stroke-opacity="${(0.15 + r() * 0.35).toFixed(2)}"/>`;
    }
    if (kind === "guide") motif += `<path d="M60 300Q200 220 300 250T520 120" ${line} stroke-width="3" stroke-dasharray="2 9" stroke-linecap="round"/><circle cx="520" cy="120" r="8" fill="${ac}"/>`;
  } else if (kind === "pricing") {
    for (let i = 0; i < 5; i++) motif += `<path d="M${120 + i * 18} ${250 - i * 34}h300l60 -24h-300z" fill="${ac}" opacity="${(0.1 + i * 0.07).toFixed(2)}" stroke="${ac}" stroke-opacity=".5"/>`;
  } else if (kind === "analysis") {
    for (let i = 0; i < 9; i++) motif += `<path d="M0 ${i * 40}H${W}" ${line} stroke-opacity=".12"/><path d="M${i * 80} 0V${H}" ${line} stroke-opacity=".12"/>`;
    let d = "M30 290"; let y = 290;
    for (let i = 1; i <= 8; i++) { y = Math.max(60, Math.min(300, y + (r() - 0.55) * 70)); d += ` L${30 + i * 76} ${y.toFixed(0)}`; }
    motif += `<path d="${d}" ${line} stroke-width="3" stroke-linejoin="round"/>`;
  } else if (kind === "media") {
    motif += `<rect x="70" y="60" width="500" height="240" rx="6" ${line} stroke-opacity=".55" stroke-width="2"/>`;
    for (let i = 0; i < 12; i++) motif += `<rect x="${86 + i * 40}" y="70" width="14" height="8" fill="${ac}" opacity=".35"/><rect x="${86 + i * 40}" y="282" width="14" height="8" fill="${ac}" opacity=".35"/>`;
    motif += `<path d="M285 140l90 40-90 40z" fill="${ac}" opacity=".85"/>`;
  } else if (kind === "update") {
    motif += `<path d="M60 ${H / 2}H${W - 60}" ${line} stroke-opacity=".6" stroke-width="2"/>`;
    for (let i = 0; i < 6; i++) { const x = 90 + i * 92; motif += `<circle cx="${x}" cy="${H / 2}" r="${i === 4 ? 12 : 7}" fill="${i === 4 ? ac : c0}" stroke="${ac}" stroke-width="2"/><path d="M${x} ${H / 2 + 16}v${20 + r() * 40}" ${line} stroke-opacity=".4"/>`; }
  } else {
    motif += `<circle cx="${W * 0.7}" cy="${H * 0.62}" r="86" fill="${ac}" opacity=".16"/><circle cx="${W * 0.7}" cy="${H * 0.62}" r="40" fill="${ac}" opacity=".7"/>`;
    for (let i = 0; i < 11; i++) { const w = 22 + r() * 36, h = 40 + r() * 130, x = 20 + i * 52; motif += `<rect x="${x}" y="${H - h}" width="${w.toFixed(0)}" height="${h.toFixed(0)}" fill="#050b14" opacity=".85"/>`; }
    motif += `<rect y="${H - 22}" width="${W}" height="22" fill="#050b14" opacity=".9"/>`;
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c0}"/><stop offset="1" stop-color="${c1}"/></linearGradient></defs>
<rect width="${W}" height="${H}" fill="url(#g)"/>${motif}
</svg>`;
}
