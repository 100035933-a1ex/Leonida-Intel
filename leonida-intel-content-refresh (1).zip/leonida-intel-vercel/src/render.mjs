// Layout and reusable components. Everything returns HTML strings; all text passes through esc()/inline().
import { SITE, NAV } from "./site.mjs";
import { esc, inline, plain, fmtDate } from "./util.mjs";
import { artKind } from "./art.mjs";

export const ctx = { assetVersion: "dev" };

// ---------- Icons (decorative; always aria-hidden) ----------
const svg = (d, extra = "") => `<svg class="icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" ${extra}>${d}</svg>`;
export const icons = {
  search: svg('<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>'),
  bookmark: svg('<path d="M6.5 4.5h11v15l-5.5-3.8-5.5 3.8z"/>'),
  menu: svg('<path d="M4 7h16M4 12h16M4 17h16"/>'),
  close: svg('<path d="M6 6l12 12M18 6 6 18"/>'),
  arrow: svg('<path d="M5 12h14M13 6l6 6-6 6"/>'),
  external: svg('<path d="M14 5h5v5M19 5l-8 8M18 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4"/>'),
  check: svg('<path d="m5 12.5 4.5 4.5L19 7.5"/>'),
};

// ---------- Labels ----------
export const BADGES = {
  official: "Official source",
  reported: "Reported",
  analysis: "Analysis",
  rumor: "Rumor",
  speculation: "Speculation",
  scheduled: "Scheduled",
  website: "Website update",
  unconfirmed: "Unconfirmed",
  partial: "Partly corroborated",
  resolved: "Resolved",
  site: "About this site",
  confirmed: "Official answer",
  planned: "Planned",
  sample: "Sample",
};
export const badge = (kind, label) => `<span class="badge badge--${esc(kind)}">${esc(label || BADGES[kind] || kind)}</span>`;

// ---------- Head / layout ----------
const abs = (p) => (SITE.baseUrl ? SITE.baseUrl + p : p);

export function layout({ title, description, path, body, type = "website", image = "/assets/og-image.png", jsonld, noindex = false, section = "" }) {
  const fullTitle = path === "/" ? `${SITE.name}: ${SITE.tagline}` : `${title} · ${SITE.name}`;
  const canonical = SITE.baseUrl ? `<link rel="canonical" href="${esc(abs(path))}">` : "";
  const ld = jsonld ? `<script type="application/ld+json">${JSON.stringify(jsonld).replace(/</g, "\\u003c")}</script>` : "";
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(description)}">
<meta name="theme-color" content="#0a1220">
<meta name="color-scheme" content="dark">
${noindex ? '<meta name="robots" content="noindex">' : ""}
${canonical}
<meta property="og:site_name" content="${esc(SITE.name)}">
<meta property="og:type" content="${esc(type)}">
<meta property="og:title" content="${esc(fullTitle)}">
<meta property="og:description" content="${esc(description)}">
${SITE.baseUrl ? `<meta property="og:url" content="${esc(abs(path))}">` : ""}
<meta property="og:image" content="${esc(abs(image))}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Leonida Intel: independent GTA 6 intelligence, unofficial fan project">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(fullTitle)}">
<meta name="twitter:description" content="${esc(description)}">
<meta name="twitter:image" content="${esc(abs(image))}">
<link rel="icon" href="/assets/mark.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
<link rel="stylesheet" href="/styles.css?v=${ctx.assetVersion}">
<script defer src="/app.js?v=${ctx.assetVersion}"></script>
${ld}
</head>
<body data-section="${esc(section)}">
<a class="skip" href="#main">Skip to main content</a>
${header(path)}
<main id="main" tabindex="-1">
${body}
</main>
${footer()}
<div id="toast" class="toast" role="status" aria-live="polite" aria-atomic="true"></div>
</body>
</html>
`;
}

function header(path) {
  const items = NAV.map((n) => {
    const active = path === n.href || path.startsWith(n.href + "/");
    return `<li><a class="nav__link" href="${n.href}"${active ? ' aria-current="page"' : ""}>${esc(n.short || n.label)}</a></li>`;
  }).join("");
  const searchActive = path === "/search" ? ' aria-current="page"' : "";
  const watchActive = path === "/watchlist" ? ' aria-current="page"' : "";
  return `<header class="site-header">
<div class="wrap header__inner">
<a class="brand" href="/" aria-label="${esc(SITE.name)} home"><img src="/assets/mark.svg" width="36" height="36" alt=""><span class="brand__text">LEONIDA <b>INTEL</b><small>UNOFFICIAL · INDEPENDENT</small></span></a>
<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav"><span class="nav-toggle__open">${icons.menu}</span><span class="nav-toggle__close">${icons.close}</span><span class="sr-only">Menu</span></button>
<nav id="site-nav" class="site-nav" aria-label="Primary">
<ul class="nav__list">${items}</ul>
<div class="nav__tools">
<a class="tool" href="/search"${searchActive}>${icons.search}<span>Search</span></a>
<a class="tool" href="/watchlist"${watchActive}>${icons.bookmark}<span>Watchlist</span><span class="count" data-watch-count hidden>0</span></a>
</div>
</nav>
</div>
</header>`;
}

function footer() {
  const links = NAV.map((n) => `<li><a href="${n.href}">${esc(n.label)}</a></li>`).join("");
  return `<footer class="site-footer">
<div class="wrap footer__grid">
<div class="footer__about">
<a class="brand" href="/" aria-label="${esc(SITE.name)} home"><img src="/assets/mark.svg" width="36" height="36" alt=""><span class="brand__text">LEONIDA <b>INTEL</b><small>UNOFFICIAL · INDEPENDENT</small></span></a>
<p class="footer__disclaimer">${esc(SITE.disclaimer)}</p>
</div>
<div><h2 class="footer__h">Sections</h2><ul class="footer__list">${links}</ul></div>
<div><h2 class="footer__h">The desk</h2><ul class="footer__list"><li><a href="/search">Search everything</a></li><li><a href="/watchlist">Your watchlist</a></li><li><a href="/about">About &amp; editorial standards</a></li></ul></div>
</div>
<div class="wrap footer__base"><span>Content last reviewed ${esc(fmtDate(SITE.lastReviewed))}</span><span>No tracking cookies. Your watchlist is stored only in this browser.</span></div>
</footer>`;
}

// ---------- Small components ----------
export const dateTag = (iso, label) => `<time datetime="${esc(iso)}">${esc(label || fmtDate(iso))}</time>`;

export const saveBtn = (type, slug, title) =>
  `<button class="save" type="button" data-save="${esc(type)}:${esc(slug)}" data-title="${esc(title)}" aria-pressed="false"><span class="save__icon">${icons.bookmark}</span><span class="save__label">Save</span><span class="sr-only"> “${esc(title)}” to watchlist</span></button>`;

export const pageHead = ({ eyebrow, title, intro, extra = "" }) => `<section class="page-head">
<div class="wrap">
<p class="eyebrow">${esc(eyebrow)}</p>
<h1 class="page-head__title">${esc(title)}</h1>
<p class="page-head__intro">${esc(intro)}</p>
${extra}
</div>
</section>`;

export const sourcesBlock = (sources, note = true) => {
  if (!sources || !sources.length) return "";
  const items = sources
    .map((s) => `<li><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.name)}<span class="sr-only"> (opens in a new tab)</span> ${icons.external}</a>${s.official ? ' <span class="tag tag--official">Official</span>' : ""}</li>`)
    .join("");
  return `<aside class="sources" aria-labelledby="sources-h"><h2 id="sources-h" class="sources__h">Sources</h2><ol class="sources__list">${items}</ol>${note ? `<p class="sources__note">External links were gathered on ${esc(fmtDate(SITE.lastReviewed))} and may change. We link to sources; we do not reproduce them.</p>` : ""}</aside>`;
};

export function blocks(body) {
  return body
    .map(([kind, a, b]) => {
      if (kind === "p") return `<p>${inline(a)}</p>`;
      if (kind === "h2") return `<h2>${esc(a)}</h2>`;
      if (kind === "ul") return `<ul>${a.map((i) => `<li>${inline(i)}</li>`).join("")}</ul>`;
      if (kind === "callout") {
        const title = { known: "What’s confirmed", unknown: "Still unconfirmed", note: "Note" }[a] || "Note";
        return `<aside class="callout callout--${esc(a)}"><strong class="callout__title">${esc(title)}</strong><p>${inline(b)}</p></aside>`;
      }
      return "";
    })
    .join("\n");
}

const lc = (...parts) => parts.flat().filter(Boolean).join(" ").toLowerCase();
export const attrText = (...parts) => esc(lc(...parts.map((p) => plain(String(p)))));

// ---------- Item cards ----------
export const artUrl = (type, slug) => `/assets/art/${type}-${slug}.svg`;

export function newsCard(n, { compact = false } = {}) {
  const url = `/news/${n.slug}`;
  return `<article class="card card--news${compact ? " card--compact" : ""}" data-item data-category="${esc(n.category)}" data-label="${esc(n.verification)}" data-date="${esc(n.date)}" data-text="${attrText(n.title, n.summary, n.tags, n.category)}">
<a class="card__media" href="${url}" tabindex="-1" aria-hidden="true"><img src="${artUrl("news", n.slug)}" alt="" width="640" height="360" loading="lazy" decoding="async"></a>
<div class="card__body">
<div class="card__meta">${badge(n.verification)}<span class="meta__cat">${esc(n.category)}</span>${dateTag(n.date)}</div>
<h3 class="card__title"><a href="${url}">${esc(n.title)}</a></h3>
<p class="card__summary">${esc(n.summary)}</p>
<div class="card__foot"><a class="more" href="${url}">Read article ${icons.arrow}</a>${saveBtn("news", n.slug, n.title)}</div>
</div>
</article>`;
}

export function rumorCard(r, { showSave = true } = {}) {
  const url = `/rumors/${r.slug}`;
  return `<article class="card card--rumor" id="${esc(r.slug)}" data-item data-topic="${esc(r.topic)}" data-status="${esc(r.status)}" data-date="${esc(r.date)}" data-text="${attrText(r.title, r.claim, r.summary, r.tags, r.origin)}">
<div class="card__body">
<div class="card__meta">${badge("rumor")}${badge(r.status)}${dateTag(r.date, r.dateLabel)}</div>
<h3 class="card__title"><a href="${url}">${esc(r.title)}</a></h3>
<p class="card__summary">${esc(r.summary)}</p>
<dl class="kv"><div><dt>Source</dt><dd>${esc(r.origin)}</dd></div><div><dt>Our label</dt><dd>${esc(rumorConfidenceLabel(r.confidence))}</dd></div></dl>
<div class="card__foot"><a class="more" href="${url}">What’s known and what isn’t ${icons.arrow}</a>${showSave ? saveBtn("rumor", r.slug, r.title) : ""}</div>
</div>
</article>`;
}

import { CONFIDENCE } from "./content/rumors.mjs";
export const rumorConfidenceLabel = (c) => `${CONFIDENCE[c].label}: ${CONFIDENCE[c].note}`;

export function updateItem(u, { today }) {
  const upcoming = u.kind === "scheduled" || u.date > today;
  const src = u.source
    ? `<a class="more more--ext" href="${esc(u.source.url)}" target="_blank" rel="noopener noreferrer">Source: ${esc(u.source.name)}<span class="sr-only"> (opens in a new tab)</span> ${icons.external}</a>`
    : `<span class="muted">First-party update about this website.</span>`;
  return `<li class="tl__item${upcoming ? " is-upcoming" : ""}" id="${esc(u.slug)}" data-item data-filter="${esc(u.filters.join("|"))}" data-date="${esc(u.date)}" data-text="${attrText(u.title, u.summary, u.tags)}">
<div class="tl__date">${dateTag(u.date)}${upcoming ? '<span class="tl__tag">Upcoming</span>' : ""}</div>
<div class="tl__card">
<div class="card__meta">${badge(u.kind)}</div>
<h3 class="tl__title">${esc(u.title)}</h3>
<p>${esc(u.summary)}</p>
<div class="card__foot">${src}${saveBtn("update", u.slug, u.title)}</div>
</div>
</li>`;
}

export function qaItem(q, topicLabel) {
  const sources = q.sources.length
    ? `<ul class="qa__sources">${q.sources.map((s) => `<li><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.name)}<span class="sr-only"> (opens in a new tab)</span> ${icons.external}</a></li>`).join("")}</ul>`
    : "";
  return `<details class="qa" id="${esc(q.slug)}" data-item data-topic="${esc(q.topic)}" data-date="${esc(q.date)}" data-text="${attrText(q.question, q.answer, q.tags, topicLabel)}">
<summary class="qa__q"><span class="qa__title">${esc(q.question)}</span>${badge(q.status === "site" ? "site" : q.status === "confirmed" ? "confirmed" : q.status)}</summary>
<div class="qa__a">
<p>${esc(q.answer)}</p>
<p class="qa__meta">${esc(topicLabel)} · Reviewed ${dateTag(q.date)}</p>
${sources}
<div class="card__foot">${saveBtn("question", q.slug, q.question)}</div>
</div>
</details>`;
}

export function guideCard(g) {
  const url = `/guides/${g.slug}`;
  return `<article class="card card--guide" data-item data-level="${esc(g.level)}" data-tag="${esc(g.tags.join("|"))}" data-date="${esc(g.date)}" data-text="${attrText(g.title, g.summary, g.tags, g.level)}">
<a class="card__media" href="${url}" tabindex="-1" aria-hidden="true"><img src="${artUrl("guide", g.slug)}" alt="" width="640" height="360" loading="lazy" decoding="async"></a>
<div class="card__body">
<div class="card__meta">${g.level === "Speculative" ? badge("speculation") : `<span class="badge badge--level">${esc(g.level)}</span>`}<span class="meta__cat">${g.readMinutes} min read</span></div>
<h3 class="card__title"><a href="${url}">${esc(g.title)}</a></h3>
<p class="card__summary">${esc(g.summary)}</p>
<div class="card__foot"><a class="more" href="${url}">Read guide ${icons.arrow}</a>${saveBtn("guide", g.slug, g.title)}</div>
</div>
</article>`;
}

// ---------- Filter controls ----------
export function chipGroup(group, label, options) {
  const chips = [{ value: "all", label: "All" }, ...options]
    .map((o, i) => `<button type="button" class="chip" data-value="${esc(o.value)}" aria-pressed="${i === 0 ? "true" : "false"}">${esc(o.label)}</button>`)
    .join("");
  return `<div class="chips" role="group" aria-label="${esc(label)}" data-group="${esc(group)}"><span class="chips__label" aria-hidden="true">${esc(label)}</span>${chips}</div>`;
}

export function filterBar({ searchLabel, placeholder, groups = [], sort = false }) {
  return `<div class="filters">
<div class="filters__row">
<label class="field field--search"><span class="sr-only">${esc(searchLabel)}</span>${icons.search}<input type="search" data-q placeholder="${esc(placeholder)}" autocomplete="off" enterkeyhint="search"></label>
${sort ? `<label class="field field--select"><span class="field__label">Sort</span><select data-sort><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select></label>` : ""}
</div>
${groups.join("\n")}
<p class="filters__count" data-count aria-live="polite"></p>
</div>`;
}

export const emptyState = (title, text) => `<div class="empty" data-empty hidden><p class="empty__title">${esc(title)}</p><p>${esc(text)}</p><button type="button" class="btn btn--ghost" data-reset>Clear search and filters</button></div>`;

export const kindFor = (type, item) => artKind(type, item.category || "");
