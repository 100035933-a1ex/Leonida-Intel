// UPDATES TIMELINE
// kind: "official" (published by Rockstar), "reported" (third-party reporting), "website" (about this site),
//       "scheduled" (a future date Rockstar has announced).
// filters: any of "official" | "release" | "features" | "website"  (these drive the filter chips)
// Every claim that depends on an outside source needs a `source`. Website updates are first-party.
import { S } from "./sources.mjs";

export const UPDATE_FILTERS = [
  { value: "official", label: "Official announcements" },
  { value: "release", label: "Release information" },
  { value: "features", label: "Game features" },
  { value: "website", label: "Website updates" },
];

export const UPDATES = [
  { slug: "vice-city-collection", date: "2026-09-24", kind: "official", filters: ["official", "features"],
    title: "Goodtime State — Vice City Collection announced", summary: "Rockstar introduced a premium collectible set associated with Grand Theft Auto VI. Availability can change; check the official listing for current details.", source: S.rsCollection, tags: ["collection", "collectibles", "rockstar store"] },
  { slug: "official-album-announcement", date: "2026-09-17", kind: "official", filters: ["official", "features"],
    title: "Grand Theft Auto VI: The Album announced", summary: "Rockstar announced the official 34-track album, scheduled to launch on November 19 alongside the game.", source: S.rsAlbum, tags: ["album", "soundtrack", "music"] },
  { slug: "launch-day", date: "2026-11-19", kind: "scheduled", filters: ["official", "release"],
    title: "Scheduled launch day", summary: "Grand Theft Auto VI is scheduled to launch on PlayStation 5 and Xbox Series X|S. This is a scheduled date, not a past event.", source: S.rsLaunchTrailer, tags: ["release date", "launch"] },
  { slug: "preload-opens", date: "2026-11-12", kind: "scheduled", filters: ["official", "release"],
    title: "Scheduled preload start", summary: "Digital pre-orders can preload from this date, and the physical edition (a box with a download code) is also available from it.", source: S.rsPreorder, tags: ["preload", "pre-order", "physical"] },
  { slug: "website-launch", date: "2026-10-18", kind: "website", filters: ["website"],
    title: "Leonida Intel opens with six sections", summary: "News, Updates, Rumors, Questions, Guides and Membership Plans are live, along with site-wide search and a browser-based watchlist.", tags: ["website", "launch"] },
  { slug: "launch-trailer", date: "2026-10-15", kind: "official", filters: ["official", "release", "features"],
    title: "Launch Trailer released", summary: "Rockstar published the Launch Trailer with new music from Justice and restated the November 19 release.", source: S.rsLaunchTrailer, tags: ["trailer", "music"] },
  { slug: "radio-stations-preview", date: "2026-10-08", kind: "official", filters: ["official", "features"],
    title: "Six in-game radio stations previewed", summary: "Rockstar added station previews to the official site’s Music section. More stations are expected but not yet announced.", source: S.rsMusic, tags: ["radio", "music"] },
  { slug: "game-informer-cover-story", date: "2026-09-29", kind: "reported", filters: ["features"],
    title: "Game Informer details weather and wildlife", summary: "Reporting based on Rockstar interviews says Leonida has hurricanes, tropical storms and 170+ animal species. This is reporting, not a Rockstar post.", source: S.giAnimals, tags: ["weather", "wildlife"] },
  { slug: "album-announced", date: "2026-09-17", kind: "official", filters: ["official", "features"],
    title: "Soundtrack album announced", summary: "Grand Theft Auto VI: The Album, with 34 original tracks and six singles, releases on launch day.", source: S.rsAlbum, tags: ["album", "music"] },
  { slug: "extended-look", date: "2026-08-27", kind: "official", filters: ["official", "features"],
    title: "“An Extended Look” released", summary: "A longer look at the game, captured in-game on PlayStation 5, premiered on Netflix and then reached YouTube and the official site.", source: S.rsExtendedLook, tags: ["trailer", "gameplay"] },
  { slug: "pricing-and-editions", date: "2026-06-24", kind: "official", filters: ["official", "release"],
    title: "Pre-orders, editions and pricing detailed", summary: "Pre-orders opened June 25 with Standard and Ultimate editions. Prices were reported from Rockstar’s press release as $79.99 and $99.99 in the U.S.", source: S.rsPreorder, tags: ["price", "pre-order", "editions"] },
  { slug: "new-date-november", date: "2025-11-06", kind: "official", filters: ["official", "release"],
    title: "Release moved to November 19, 2026", summary: "Rockstar announced a second date change, citing time to finish the game with the polish it wants.", source: S.rsDelayNov, tags: ["release date", "delay"] },
  { slug: "trailer-2", date: "2025-05-06", kind: "official", filters: ["official", "features"],
    title: "Trailer 2 released", summary: "Rockstar published a second trailer, listed on its Grand Theft Auto VI Newswire archive.", source: S.rsNewswire, tags: ["trailer"] },
  { slug: "new-date-may", date: "2025-05-02", kind: "official", filters: ["official", "release"],
    title: "Release moved to May 26, 2026", summary: "Rockstar announced the first date change, from its original 2025 target.", source: S.rsDelayMay, tags: ["release date", "delay"] },
  { slug: "announcement", date: "2023-12-04", kind: "official", filters: ["official", "release"],
    title: "Grand Theft Auto VI formally announced", summary: "Rockstar announced the game for PlayStation 5 and Xbox Series X|S, targeting 2025, with its first trailer following.", source: S.bwAnnounce, tags: ["announcement", "trailer"] },
];
