// NEWS CONTENT
// Add a new article by appending an object to this array. Fields:
//   slug          URL slug  -> /news/<slug>
//   title, summary, date (YYYY-MM-DD)
//   category      one of NEWS_CATEGORIES
//   verification  "official" (published by Rockstar) | "reported" (third-party reporting) | "analysis" (our opinion)
//   tags          lowercase keywords used for search and related articles
//   body          blocks: ["p", text] ["h2", text] ["ul", [items]] ["callout", "known"|"unknown"|"note", text]
//                 inline: **bold** and [text](https://link)
//   sources       [{ name, url }]  (import from ./sources.mjs)
// Write in your own words. Never invent quotes, sources, dates or features.
import { S } from "./sources.mjs";

export const NEWS_CATEGORIES = ["Release", "Trailers & Media", "Music", "Game Features", "Editions & Pricing", "Analysis"];

export const NEWS = [
  {
    slug: "gta-vi-collection-rockstar-store",
    title: "Rockstar highlights the Goodtime State — Vice City Collection",
    summary: "Rockstar's September Newswire post introduced a premium collectible set tied to Grand Theft Auto VI. Availability and stock can change, so check the official listing for current details.",
    date: "2026-09-24",
    category: "Editions & Pricing",
    verification: "official",
    tags: ["collection", "collectibles", "rockstar store", "vice city", "merchandise"],
    body: [
      ["p", "Rockstar Games introduced the Goodtime State — Vice City Collection through its Newswire on September 24, 2026. The announcement describes a premium collectible set associated with Grand Theft Auto VI."],
      ["p", "This is a merchandise announcement, not a change to the game's release date or a confirmation of new gameplay features. Product availability, contents, and shipping details should be checked on the official store listing before making a purchase."],
      ["callout", "known", "Rockstar's own Newswire is the primary source for the collection announcement."],
      ["callout", "unknown", "Stock and current availability may change after publication; this article does not guarantee that the collection is still available."],
    ],
    sources: [S.rsCollection],
  },
  {
    slug: "launch-trailer-justice-score",
    title: "Rockstar releases the GTA 6 launch trailer, with new music from Justice",
    summary: "A new Launch Trailer arrived on October 15, five weeks before the November 19 release, with new music from the duo Rockstar credits with the game’s original score.",
    date: "2026-10-15",
    category: "Trailers & Media",
    verification: "official",
    tags: ["trailer", "music", "launch", "release date", "justice"],
    body: [
      ["p", "Rockstar Games published a Launch Trailer for Grand Theft Auto VI on October 15, 2026, according to its Newswire. The post repeats that the game arrives on November 19 for PlayStation 5 and Xbox Series X|S."],
      ["p", "The trailer features new music from the electronic duo Justice, whom Rockstar describes as the composers of the game’s original score. Rockstar’s post also lists a new single from the duo, titled “Flower in a Hurricane,” and points readers to the official soundtrack album."],
      ["callout", "known", "Rockstar says the game launches November 19 on PS5 and Xbox Series X|S, and that more information about the game’s music is coming."],
      ["callout", "unknown", "The announcement does not describe new gameplay systems or any change to launch plans. Anything beyond the post itself is commentary, not confirmation."],
      ["p", "For the bigger picture on music, see our guide to the soundtrack, radio and the album."],
    ],
    sources: [S.rsLaunchTrailer, S.rsMusic],
  },
  {
    slug: "six-radio-stations-previewed",
    title: "Rockstar previews six Leonida radio stations on the official GTA 6 site",
    summary: "Station previews went live on October 8 and cover Latin, country, African classics, metal, pop and Southern hip-hop. It is not the full lineup.",
    date: "2026-10-08",
    category: "Music",
    verification: "official",
    tags: ["radio", "music", "stations", "soundtrack"],
    body: [
      ["p", "Rockstar added a Music section to the official Grand Theft Auto VI site and announced it through the Newswire on October 8, 2026. It lets visitors listen to previews of six in-game radio stations."],
      ["h2", "The six stations previewed"],
      ["ul", ["Cocoteo FM: modern Latin music", "Back Country Radio: country", "AfroBank FM: African classics", "The Chamber 106.6: heavy metal", "Flash FM: pop", "Dirty South Classics: rap and hip-hop"]],
      ["p", "Rockstar describes the full radio lineup as ranging from classic rock to talk radio, which means more stations exist than the six previewed. One outlet also reports that podcasts you can download and play on the in-game phone are a first for the series; treat that detail as reported rather than something we confirmed on Rockstar’s page."],
      ["callout", "unknown", "Rockstar has not said how the 34-track soundtrack album relates to the songs on in-game radio, and the remaining stations and hosts are not yet announced."],
    ],
    sources: [S.rsRadioStations, S.rsMusic, S.giRadio, S.psuRadio, S.keenRadio, S.eftmRadio],
  },
  {
    slug: "game-informer-cover-story-hurricanes-wildlife",
    title: "Game Informer cover story: hurricanes and more than 170 animal species in Leonida",
    summary: "Reporting from Game Informer’s September 29 cover story says Leonida will have tropical storms, hurricanes and a very large animal roster.",
    date: "2026-09-29",
    category: "Game Features",
    verification: "reported",
    tags: ["weather", "hurricanes", "wildlife", "animals", "game informer", "leonida"],
    body: [
      ["p", "Game Informer published a cover story on September 29, 2026, based on interviews with Rockstar. Coverage of it says tropical storms and hurricanes will occur in Leonida, as part of a more detailed weather system."],
      ["p", "The same story says Leonida contains more than 170 animal species across land, water and air, including some that have never appeared in a Rockstar game. Game Informer’s public summary mentions native Florida animals alongside invasive species, and says certain animals are grouped as Rare, Discoverable or Legendary, with the specific animals kept secret. Rockstar is reported to be building on animal technology developed for the Red Dead Redemption series."],
      ["callout", "known", "According to Game Informer’s account of its Rockstar interviews: hurricanes and tropical storms exist in Leonida, and the world has 170+ animal species."],
      ["callout", "unknown", "We have not read the full 14-page article ourselves, and the public summaries we reviewed do not say how storms affect missions, traffic or police behavior. Do not assume any such effects until Rockstar or the full article confirms them."],
    ],
    sources: [S.giAnimals, S.gosuHurricanes, S.hotHardware],
  },
  {
    slug: "the-album-34-tracks-november-19",
    title: "“Grand Theft Auto VI: The Album” announced: 34 tracks, out on launch day",
    summary: "Rockstar and Atlantic Records announced a 34-track soundtrack album on September 17, with six singles available immediately and CD and vinyl editions.",
    date: "2026-09-17",
    category: "Music",
    verification: "official",
    tags: ["album", "soundtrack", "music", "atlantic records", "vinyl"],
    body: [
      ["p", "Rockstar Games and Atlantic Records announced Grand Theft Auto VI: The Album on September 17, 2026. It collects 34 original tracks and releases November 19, the same day as the game."],
      ["p", "Six singles were released with the announcement: Yung Lean (feat. Future and Metro Boomin), Travis Scott, a collaboration between CA7RIEL & Paco Amoroso, PinkPantheress, Fred again.. and Etienne de Crécy, Morgan Wallen, Rauw Alejandro and Keith Richards. Pre-save is open on streaming services."],
      ["p", "Physical editions are planned at launch. Reporting on the announcement lists U.S. prices of $19.98 for the CD, $49.98 for a standard vinyl and $124.98 for a limited-edition vinyl, with some editions sold only through the album’s official store. Prices and retailers can change, so check the listing before buying."],
      ["callout", "unknown", "A full track list beyond the six singles has not been published in the sources we reviewed."],
    ],
    sources: [S.rsAlbum, S.gematsuAlbum],
  },
  {
    slug: "extended-look-aug-27",
    title: "“An Extended Look” premieres, built entirely from in-game footage",
    summary: "Rockstar’s longer look at the game aired on Netflix and then arrived on YouTube and the official site on August 27.",
    date: "2026-08-27",
    category: "Trailers & Media",
    verification: "official",
    tags: ["trailer", "extended look", "netflix", "gameplay"],
    body: [
      ["p", "Rockstar Games released Grand Theft Auto VI: An Extended Look on August 27, 2026. It played on Netflix first, then arrived on Rockstar’s YouTube channel and the official game site later that evening."],
      ["p", "Rockstar says the footage was captured entirely in-game on PlayStation 5. The Newswire post also restates the November 19 release and invites readers to pre-order."],
      ["callout", "note", "A video is a snapshot of a work in progress. Tuning, visuals and content can change before release, so we label anything inferred from footage as analysis rather than fact."],
    ],
    sources: [S.rsExtendedLook, S.rsNewswire],
  },
  {
    slug: "pricing-editions-preload-dates",
    title: "Price, editions and preload dates confirmed: $79.99 Standard, $99.99 Ultimate",
    summary: "Rockstar opened pre-orders on June 25 with two editions. Digital preload starts November 12, and the physical edition is a box with a download code.",
    date: "2026-06-24",
    category: "Editions & Pricing",
    verification: "official",
    tags: ["price", "pre-order", "ultimate edition", "preload", "physical", "editions"],
    body: [
      ["p", "Pre-orders opened at midnight local time on June 25, 2026. Rockstar’s announcement describes a Standard Edition and a Grand Theft Auto VI: Ultimate Edition, which adds an exclusive collection of vehicles, weapons, apparel and other content."],
      ["h2", "What was announced"],
      ["ul", [
        "Prices reported from Rockstar’s press release: $79.99 for Standard and $99.99 for Ultimate (U.S.). Regional prices differ.",
        "Anyone who pre-orders or buys before November 20 gets the Vintage Vice City Pack.",
        "Digital pre-orders can preload from November 12.",
        "The physical edition is a box containing a download code, available from November 12 for preloading, with no game disc.",
        "Reporting on the press release says Standard owners can upgrade to Ultimate later for the $20 difference.",
      ]],
      ["callout", "unknown", "Download size and the complete contents of the Vintage Vice City Pack were not itemized in the sources we reviewed."],
    ],
    sources: [S.rsPreorder, S.nbPrice, S.techRadarPrice, S.mp1stEditions],
  },
  {
    slug: "release-date-history",
    title: "How GTA 6 got to November 19, 2026: every official date change",
    summary: "From “2025” in the first announcement to May 26, 2026 and then November 19, 2026, here is the dated record straight from Rockstar’s own posts.",
    date: "2026-10-18",
    category: "Release",
    verification: "official",
    tags: ["release date", "delay", "timeline", "november 19", "may 26"],
    body: [
      ["p", "Release timing has moved twice. Each change below comes from a post Rockstar published itself."],
      ["ul", [
        "**December 2023:** Rockstar formally announced Grand Theft Auto VI for PlayStation 5 and Xbox Series X|S, saying it was coming in 2025.",
        "**May 2, 2025:** Rockstar announced a new date of May 26, 2026.",
        "**November 6, 2025:** Rockstar announced a further move to Thursday, November 19, 2026, saying the extra time would let it finish the game with the polish it wanted.",
      ]],
      ["p", "Since then Rockstar’s communications have consistently pointed to November 19, including the pre-order announcement and the October launch trailer."],
      ["callout", "note", "This article is a reference page. If the date ever changes again, the Updates timeline will carry the new official announcement first."],
    ],
    sources: [S.bwAnnounce, S.rsDelayMay, S.rsDelayNov, S.rsNewswire],
  },
  {
    slug: "analysis-gta-online-what-is-confirmed",
    title: "Analysis: Five weeks out, what is actually confirmed about GTA 6 Online?",
    summary: "Rockstar has framed launch as a single-player experience and announced nothing about an online mode. Here is how to read the gap, and where the rumors fit.",
    date: "2026-10-18",
    category: "Analysis",
    verification: "analysis",
    tags: ["online", "multiplayer", "analysis", "gta online", "rumors"],
    body: [
      ["callout", "note", "This is analysis and opinion from Leonida Intel. The facts it relies on are sourced below; the interpretation is ours and could be wrong."],
      ["h2", "What is confirmed"],
      ["p", "Rockstar’s pre-order announcement describes Grand Theft Auto VI as a single-player experience coming November 19. In the Newswire posts we reviewed, Rockstar has not announced an online mode, a name for one, or a date."],
      ["h2", "What is only rumored"],
      ["p", "Outlets have attributed an “online arrives next year” remark to the CEO of Twitch. That is a third-party comment, not a Rockstar statement; see our [rumor entry](/rumors/online-mode-next-year-claim) for the sourcing and caveats."],
      ["h2", "How we read it"],
      ["p", "Our view is that the silence tells us about Rockstar’s marketing priorities, not about the game’s future. The studio has launched online features after a game before: Grand Theft Auto Online arrived on October 1, 2013, roughly two weeks after Grand Theft Auto V’s September 17 launch. That precedent does not mean the same will happen again, and we are not predicting it."],
      ["p", "Until Rockstar says more, the responsible position is simple: single-player at launch is confirmed, everything else about online is open."],
    ],
    sources: [S.rsPreorder],
  },
];
