// Central registry of external sources, so every entry links to the same, reviewed URL.
// All URLs below were returned by web searches on 2026-10-18. Re-check them before launch and
// whenever you add content: external pages can move or change.
export const S = {
  // ----- Official (Rockstar Games) -----
  rsLaunchTrailer: { name: "Rockstar Newswire: Watch the Grand Theft Auto VI Launch Trailer", url: "https://www.rockstargames.com/newswire/article/517572321a549a/watch-the-grand-theft-auto-vi-launch-trailer", official: true },
  rsPreorder: { name: "Rockstar Newswire: Pre-Order Grand Theft Auto VI on June 25", url: "https://www.rockstargames.com/newswire/article/5171972o3ak5oa/pre-order-grand-theft-auto-vi-on-june-25", official: true },
  rsExtendedLook: { name: "Rockstar Newswire: An Extended Look — Now Playing", url: "https://www.rockstargames.com/newswire/article/4k138k8okkk483/grand-theft-auto-vi-an-extended-look-now-playing", official: true },
  rsDelayNov: { name: "Rockstar Newswire: Now Set to Launch November 19, 2026", url: "https://www.rockstargames.com/newswire/article/ak3ak31a49a221/grand-theft-auto-vi-is-now-set-to-launch-november-19-2026", official: true },
  rsDelayMay: { name: "Rockstar Newswire: Now Coming May 26, 2026", url: "https://www.rockstargames.com/newswire/article/258aa538o412ok/grand-theft-auto-vi-is-now-coming-may-26-2026", official: true },
  rsNewswire: { name: "Rockstar Newswire (Grand Theft Auto VI archive)", url: "https://www.rockstargames.com/newswire?tag=vi", official: true },
  rsMusic: { name: "Official Grand Theft Auto VI site: Music", url: "https://rockstargames.com/vi/music", official: true },
  rsCollection: { name: "Rockstar Newswire: Grand Theft Auto VI Collection Now at the Rockstar Store", url: "https://www.rockstargames.com/newswire/article/9k2a49ook82o57/pre-order-the-goodtime-state-vice-city-collection-now-while-supplies-last", official: true },
  rsAlbum: { name: "Rockstar Newswire: Announcing Grand Theft Auto VI: The Album", url: "https://www.rockstargames.com/newswire/article/7599a881942544/announcing-grand-theft-auto-vi-the-album-coming-november-19", official: true },
  rsRadioStations: { name: "Rockstar Newswire: The Music of Grand Theft Auto VI: In-Game Radio Stations", url: "https://www.rockstargames.com/newswire/article/o3982oa93a23k4/the-music-of-grand-theft-auto-vi-in-game-radio-stations", official: true },
  bwAnnounce: { name: "Business Wire: Rockstar Games Announces Grand Theft Auto VI", url: "https://www.businesswire.com/news/home/20231204993583/en/Rockstar-Games-Announces-Grand-Theft-Auto-VI-Coming-2025", official: true },

  // ----- Reporting -----
  giAnimals: { name: "Game Informer: Grand Theft Auto VI Includes Over 170 Animal Species", url: "https://gameinformer.com/exclusive/2026/09/29/exclusive-grand-theft-auto-vi-includes-over-170-animal-species" },
  giRadio: { name: "Game Informer: The songs heard in Rockstar’s in-game radio preview", url: "https://gameinformer.com/2026/10/08/grand-theft-auto-vi-heres-all-the-songs-we-heard-in-rockstars-in-game-radio-preview" },
  gosuHurricanes: { name: "GosuGamers: hurricanes, map size and 170 animal species explained", url: "https://www.gosugamers.net/entertainment/news/79271-gta-vi-s-hurricanes-map-size-minigames-and-170-animal-species-explained-in-new-report" },
  hotHardware: { name: "HotHardware: GTA 6 adds hurricanes and legendary hunts", url: "https://hothardware.com/news/gta-6-hurricanes-legendary-hunts" },
  gtaIntelCover: { name: "GTA Intel (fan site): Game Informer cover story summary", url: "https://gtaintel.com/news/gta-6-game-informer-cover-story-new-details" },
  gematsuAlbum: { name: "Gematsu: Grand Theft Auto VI: The Album announced", url: "https://www.gematsu.com/2026/09/grand-theft-auto-vi-the-album-announced" },
  psuRadio: { name: "PSU: Grand Theft Auto VI previews a selection of radio stations", url: "https://www.psu.com/news/grand-theft-auto-vi-previews-a-selection-of-radio-stations-dedicated-to-country-heavy-metal-pop-more/" },
  keenRadio: { name: "KeenGamer: GTA 6 reveals its first six radio stations", url: "https://www.keengamer.com/articles/news/gta-6-reveals-its-first-six-radio-stations-hosted-by-bad-bunny-slayer-and-more/" },
  eftmRadio: { name: "EFTM: GTA VI radio stations go live on the official Rockstar website", url: "https://eftm.com/2026/10/listen-early-gta-vi-radio-stations-go-live-on-official-rockstar-website-281960" },
  nbPrice: { name: "Notebookcheck: GTA 6 price officially confirmed", url: "https://www.notebookcheck.net/GTA-6-price-officially-confirmed-ahead-of-pre-orders.1327919.0.html" },
  techRadarPrice: { name: "TechRadar: the official GTA 6 price", url: "https://www.techradar.com/gaming/we-finally-know-the-official-gta-6-price-its-expensive-but-not-too-bad" },
  mp1stEditions: { name: "MP1st: pre-load, pre-order bonuses and editions", url: "https://mp1st.com/news/gta-6-pre-load-pre-order-bonuses-new-screenshots-revealed-standard-edition-costs-80" },
  engadgetPrice: { name: "Engadget: Rockstar reveals GTA 6 pricing and launch details", url: "https://engadget.com/2200483/rockstar-reveals-gta-6-pricing-launch/" },
  dexertoPrice: { name: "Dexerto: GTA 6 price and Ultimate Edition", url: "https://www.dexerto.com/gta/gta-6-price-ultimate-edition-pre-orders-live-3378744/" },

  // ----- Rumor-related reporting -----
  pcGamesNPc: { name: "PCGamesN: Rockstar reportedly plans GTA 6 PC release for early 2027", url: "https://www.pcgamesn.com/grand-theft-auto-vi/pc-launch-leak" },
  pcGamerPc: { name: "PC Gamer: report claims GTA 6 will launch on PC sooner than expected", url: "https://www.pcgamer.com/games/grand-theft-auto/report-claims-grand-theft-auto-6-will-launch-on-pc-sooner-than-anyone-expected/" },
  gtaUpdateReview: { name: "GTA-Update: report on GTA 6 review copies", url: "https://gta-update.com/gta-6-review-copies/" },
  neTimesRadio: { name: "Northeast Times: Rockstar teases overhaul of GTA 6’s in-game radio", url: "https://northeasttimes.com/2026/09/17/rockstar-teases-overhaul-of-gta-6-s-in-game-radio-stations/" },
  gulfRadioLeaks: { name: "Gulf News: GTA 6 leaks reveal songs and radio stations", url: "https://gulfnews.com/technology/gaming/gta-6-leaks-reveal-songs-and-radio-stations-from-tate-mcrae-to-v-rock-1.500649697" },
  nbDelay2024: { name: "Notebookcheck: a “sketchy” 2024 rumor about a delay and a later PC version", url: "https://www.notebookcheck.net/Sketchy-GTA-6-rumor-claims-PC-release-to-follow-12-18-months-after-console-launch-which-is-pushed-to-early-mid-2026.885855.0.html" },
};
