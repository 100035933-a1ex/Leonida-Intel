// RUMORS
// Every entry is a claim made by someone else. We do not originate rumors and we never present them as fact.
// status:     "unconfirmed" | "partial" (some elements later confirmed) | "resolved" (settled by official info)
// confidence: our editorial shorthand, NOT a measurement:
//             "low"   thin or anonymous sourcing, or a remark that isn’t from Rockstar
//             "mixed" a named outlet reports it, but Rockstar has not confirmed it
//             "settled" the question has been answered officially
// dateLabel:  optional text when only an approximate date is known (date is then a sort key only)
import { S } from "./sources.mjs";

export const RUMOR_TOPICS = [
  { value: "platforms", label: "Platforms" },
  { value: "online", label: "Online" },
  { value: "release", label: "Release & reviews" },
  { value: "music", label: "Music & radio" },
  { value: "pricing", label: "Pricing" },
];

export const RUMOR_STATUS = [
  { value: "unconfirmed", label: "Unconfirmed" },
  { value: "partial", label: "Partly corroborated" },
  { value: "resolved", label: "Resolved" },
];

export const CONFIDENCE = {
  low: { label: "Low confidence", note: "Thin or anonymous sourcing, or not a Rockstar statement." },
  mixed: { label: "Mixed confidence", note: "Reported by a named outlet, but unconfirmed by Rockstar." },
  settled: { label: "Settled", note: "Answered by official information." },
};

export const RUMORS = [
  {
    slug: "pc-version-q1-2027",
    title: "GTA 6 is said to come to PC in early 2027",
    claim: "A report says Rockstar plans to release a PC version in the first quarter of 2027.",
    topic: "platforms", status: "unconfirmed", confidence: "mixed",
    origin: "GamesBeat report citing four anonymous industry sources, relayed by PCGamesN and PC Gamer",
    date: "2026-10-13",
    summary: "GamesBeat reports, via four anonymous sources, that a PC release is planned for January to March 2027. Rockstar has announced PlayStation 5 and Xbox Series X|S only.",
    known: [
      "Rockstar’s official platforms are PlayStation 5 and Xbox Series X|S.",
      "The report was published October 13, 2026 and several outlets repeated it while labeling it unconfirmed.",
      "The outlets we read say Rockstar did not respond to the original request for comment.",
    ],
    unconfirmed: [
      "That any PC version exists in development for release, and that Q1 2027 is the target.",
      "The identity and reliability of the four anonymous sources.",
    ],
    tags: ["pc", "platforms", "release window", "2027"],
    sources: [S.pcGamesNPc, S.pcGamerPc],
  },
  {
    slug: "online-mode-next-year-claim",
    title: "A Twitch executive reportedly said GTA 6’s online mode comes “next year”",
    claim: "Outlets attribute to Twitch CEO Dan Clancy a Bloomberg remark that GTA 6’s online component arrives next year.",
    topic: "online", status: "unconfirmed", confidence: "low",
    origin: "A remark attributed to a Twitch executive in a Bloomberg interview, as relayed by PCGamesN",
    date: "2026-09-30", dateLabel: "Sep 2026",
    summary: "A third party outside Rockstar is quoted as saying online arrives in 2027. Rockstar has announced no online mode and no date.",
    known: [
      "Rockstar describes the game at launch as a single-player experience.",
      "PCGamesN notes that Rockstar has not announced a launch date for any online component.",
    ],
    unconfirmed: [
      "That the remark is accurate, or that the speaker has inside knowledge of Rockstar’s plans.",
      "Whether an online mode exists, what it is called, or when it would release.",
    ],
    tags: ["online", "multiplayer", "2027"],
    sources: [S.pcGamesNPc, S.rsPreorder],
  },
  {
    slug: "review-copies-before-launch",
    title: "Review copies are said to go out before the end of October",
    claim: "Reports say Rockstar will send review copies in October and lift the review embargo before the November 19 launch.",
    topic: "release", status: "unconfirmed", confidence: "low",
    origin: "Insider Gaming reportedly learned the embargo timing; an industry insider reportedly said copies arrive in October; relayed by aggregator coverage",
    date: "2026-10-15",
    summary: "Secondhand reports claim reviews will be allowed before launch. Rockstar has announced no embargo or review schedule.",
    known: [
      "As of the October 15 coverage we reviewed, Rockstar had not announced a review embargo date.",
    ],
    unconfirmed: [
      "That review copies are being sent, and when.",
      "When reviews could be published. The coverage itself describes this as one unconfirmed report resting on another.",
    ],
    tags: ["reviews", "embargo", "release"],
    sources: [S.gtaUpdateReview],
  },
  {
    slug: "radio-hosts-dj-khaled-drake",
    title: "DJ Khaled and Drake are rumored to host GTA 6 radio stations",
    claim: "Earlier reports suggested DJ Khaled might host a radio station and that Drake might get one too.",
    topic: "music", status: "unconfirmed", confidence: "low",
    origin: "Reports summarized by a Yahoo Tech article, as relayed by Northeast Times",
    date: "2026-09-17",
    summary: "These host rumors predate Rockstar’s own radio reveal. The six stations Rockstar has previewed do not include them as far as the sources we reviewed show.",
    known: [
      "Rockstar’s official radio previews came on October 8, 2026 and name six stations.",
      "Rockstar’s soundtrack-album post named no radio hosts, according to the coverage we read.",
    ],
    unconfirmed: [
      "That either artist is involved in the game in any way.",
      "The original source of the claim, which we could not trace to a primary report.",
    ],
    tags: ["radio", "hosts", "music"],
    sources: [S.neTimesRadio, S.rsMusic],
  },
  {
    slug: "leaked-radio-station-list",
    title: "A leaked list of radio stations and songs",
    claim: "A leaker was reported to have a list of in-game radio stations and songs, including names such as CircoLoco Records Radio, Honey FM and V-Rock.",
    topic: "music", status: "partial", confidence: "mixed",
    origin: "A leaker, as summarized by Gulf News in August 2026",
    date: "2026-08-25", dateLabel: "Aug 2026",
    summary: "Two station names from that leak, Back Country Radio and Dirty South Classics, later appeared in Rockstar’s official preview. The rest remain unconfirmed.",
    known: [
      "Rockstar’s October 8 preview includes Back Country Radio and Dirty South Classics.",
      "Rockstar had confirmed none of the leaked list when Gulf News reported it.",
    ],
    unconfirmed: [
      "The other stations on the leaked list, such as CircoLoco Records Radio and V-Rock.",
      "The leaked song lists. A match on two names does not validate the rest of a leak.",
    ],
    tags: ["radio", "leak", "music"],
    sources: [S.gulfRadioLeaks, S.rsMusic],
  },
  {
    slug: "hundred-dollar-price-speculation",
    title: "Speculation that the base game would cost $100 or more",
    claim: "For about a year, commentators speculated that Rockstar and Take-Two would set the standard price at $100 or higher.",
    topic: "pricing", status: "resolved", confidence: "settled",
    origin: "Widespread community and press speculation",
    date: "2026-06-24",
    summary: "Settled on June 24, 2026: pricing reported from Rockstar’s press release put the Standard Edition at $79.99 and the Ultimate Edition at $99.99 in the U.S.",
    known: [
      "The reported U.S. prices are $79.99 (Standard) and $99.99 (Ultimate).",
      "Regional prices differ from U.S. prices.",
    ],
    unconfirmed: [
      "Nothing further. The question was answered by the official announcement. Future prices or sales are separate matters.",
    ],
    tags: ["price", "editions", "speculation"],
    sources: [S.nbPrice, S.dexertoPrice, S.rsPreorder],
  },
  {
    slug: "2024-delay-and-pc-gap-rumor",
    title: "A 2024 rumor about a 2026 delay and a PC version months later",
    claim: "In September 2024 a post on X claimed a delay to early or mid 2026, with PC following 12 to 18 months after consoles.",
    topic: "release", status: "resolved", confidence: "settled",
    origin: "An anonymous post on X, covered by Notebookcheck, and disputed at the time by journalist Jason Schreier",
    date: "2024-09-09",
    summary: "The delay half was overtaken by events: Rockstar announced May 26, 2026 in May 2025, then November 19, 2026 that November. The PC half remains unconfirmed.",
    known: [
      "Notebookcheck reported that Jason Schreier dispelled the delay rumor when it surfaced in September 2024.",
      "Rockstar later announced two official date changes (see the release history).",
    ],
    unconfirmed: [
      "The PC timing claim. Rockstar has not announced a PC version at all.",
      "Whether the original poster knew anything. A claim that later overlaps with events is not proof of inside knowledge.",
    ],
    tags: ["delay", "pc", "history"],
    sources: [S.nbDelay2024, S.rsDelayMay, S.rsDelayNov],
  },
];
