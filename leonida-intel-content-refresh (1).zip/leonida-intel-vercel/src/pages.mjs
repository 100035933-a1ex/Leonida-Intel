// Page renderers. Each returns { path, html } or a list of them.
import { SITE, NAV } from "./site.mjs";
import { NEWS, NEWS_CATEGORIES } from "./content/news.mjs";
import { UPDATES, UPDATE_FILTERS } from "./content/updates.mjs";
import { RUMORS, RUMOR_TOPICS, RUMOR_STATUS, CONFIDENCE } from "./content/rumors.mjs";
import { QUESTIONS, QUESTION_TOPICS } from "./content/questions.mjs";
import { GUIDES, GUIDE_LEVELS } from "./content/guides.mjs";
import { esc, inline, plain, fmtDate, byDateDesc, truncate } from "./util.mjs";
import {
  layout, icons, badge, BADGES, dateTag, saveBtn, pageHead, sourcesBlock, blocks, newsCard, rumorCard, updateItem,
  qaItem, guideCard, chipGroup, filterBar, emptyState, artUrl, rumorConfidenceLabel,
} from "./render.mjs";

const TODAY = process.env.BUILD_DATE || new Date().toISOString().slice(0, 10);

const news = [...NEWS].sort(byDateDesc);
const updates = [...UPDATES].sort(byDateDesc);
const rumors = [...RUMORS].sort(byDateDesc);
const guides = [...GUIDES].sort(byDateDesc);
const topicLabel = (list, v) => (list.find((t) => t.value === v) || { label: v }).label;

// Related items by shared tags (then recency). Works for any content type with `tags`.
function related(item, pool, n = 3) {
  const tags = new Set(item.tags || []);
  return pool
    .filter((o) => o.slug !== item.slug)
    .map((o) => ({ o, score: (o.tags || []).filter((t) => tags.has(t)).length }))
    .sort((a, b) => b.score - a.score || (a.o.date < b.o.date ? 1 : -1))
    .filter((x) => x.score > 0)
    .slice(0, n)
    .map((x) => x.o);
}

// ---------- Search index (also used by the watchlist) ----------
export function buildSearchIndex() {
  const out = [];
  for (const n of NEWS) out.push({ id: `news:${n.slug}`, type: "news", title: n.title, summary: n.summary, date: n.date, tags: [...n.tags, n.category.toLowerCase()], label: n.verification, url: `/news/${n.slug}`, text: plain(n.body.map((b) => (Array.isArray(b[1]) ? b[1].join(" ") : b[b.length - 1])).join(" ")).toLowerCase().slice(0, 1800) });
  for (const u of UPDATES) out.push({ id: `update:${u.slug}`, type: "update", title: u.title, summary: u.summary, date: u.date, tags: u.tags, label: u.kind, url: `/updates#${u.slug}`, text: "" });
  for (const r of RUMORS) out.push({ id: `rumor:${r.slug}`, type: "rumor", title: r.title, summary: r.summary, date: r.date, tags: [...r.tags, r.topic], label: r.status, url: `/rumors/${r.slug}`, text: [r.claim, r.origin, ...r.known, ...r.unconfirmed].join(" ").toLowerCase().slice(0, 1800) });
  for (const q of QUESTIONS) out.push({ id: `question:${q.slug}`, type: "question", title: q.question, summary: q.answer, date: q.date, tags: [...q.tags, q.topic], label: q.status, url: `/questions#${q.slug}`, text: "" });
  for (const g of GUIDES) out.push({ id: `guide:${g.slug}`, type: "guide", title: g.title, summary: g.summary, date: g.date, tags: [...g.tags, g.level.toLowerCase()], label: g.level, url: `/guides/${g.slug}`, text: plain(g.body.map((b) => (Array.isArray(b[1]) ? b[1].join(" ") : b[b.length - 1])).join(" ")).toLowerCase().slice(0, 1800) });
  return out;
}

function topTags(limit) {
  const counts = new Map();
  for (const it of buildSearchIndex()) for (const t of it.tags) counts.set(t, (counts.get(t) || 0) + 1);
  return [...counts.entries()].filter(([, c]) => c >= 2).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, limit).map(([t]) => t);
}

const legend = `<ul class="legend" aria-label="Label key">
<li>${badge("official")}<span>Published by Rockstar Games itself</span></li>
<li>${badge("reported")}<span>Third-party reporting, linked to its source</span></li>
<li>${badge("analysis")}<span>Our interpretation, not a fact</span></li>
<li>${badge("rumor")}<span>A claim from someone else, never confirmed</span></li>
<li>${badge("speculation")}<span>An educated guess</span></li>
</ul>`;

// =====================================================================
// HOME: the Intel Dashboard
// =====================================================================
export function home() {
  const verified = news.filter((n) => n.verification !== "analysis");
  const [lead, ...rest] = verified;
  const pastUpdates = updates.filter((u) => u.date <= TODAY && u.kind !== "website");
  const recentOfficial = pastUpdates.filter((u) => u.kind === "official").slice(0, 4);
  const log = [
    ...updates.filter((u) => u.date <= TODAY).map((u) => ({ type: "Update", kind: u.kind, title: u.title, date: u.date, href: `/updates#${u.slug}` })),
    ...rumors.map((r) => ({ type: "Rumor", kind: "rumor", title: r.title, date: r.date, label: r.dateLabel, href: `/rumors/${r.slug}` })),
  ].sort(byDateDesc).slice(0, 8);
  const upcoming = updates.filter((u) => u.kind === "scheduled").sort((a, b) => (a.date < b.date ? -1 : 1));

  const tiles = NAV.map((n, i) => `<a class="tile" href="${n.href}"><span class="tile__n">${String(i + 1).padStart(2, "0")}</span><span class="tile__t">${esc(n.label)}</span><span class="tile__b">${esc(n.blurb)}</span><span class="tile__go">${icons.arrow}</span></a>`).join("");
  const stats = [
    [verified.length, "sourced news items"],
    [updates.filter((u) => u.kind === "official").length, "official updates logged"],
    [rumors.length, "rumors tracked and labeled"],
    [guides.length + QUESTIONS.length, "guides and answers"],
  ].map(([n, l]) => `<li><strong>${n}</strong><span>${l}</span></li>`).join("");

  const body = `
<section class="hero">
<img class="hero__art" src="/assets/coastline.svg" alt="" width="1600" height="1000" fetchpriority="high">
<div class="hero__shade"></div>
<div class="wrap hero__inner">
<p class="eyebrow"><span class="eyebrow__line"></span>Unofficial intelligence desk · GTA 6 / Leonida</p>
<h1 class="hero__title">Know what’s confirmed.<br><i>Track what isn’t.</i></h1>
<p class="hero__deck">An independent briefing center for GTA 6: dated official updates, sourced news, clearly labeled rumors and practical guides, with a hard line between fact and speculation.</p>
<form class="hero__search" action="/search" method="get" role="search">
<label class="sr-only" for="hero-q">Search Leonida Intel</label>
${icons.search}<input id="hero-q" name="q" type="search" placeholder="Search news, rumors, guides" autocomplete="off" enterkeyhint="search" data-focus-key="/">
<button class="btn btn--primary" type="submit">Search</button>
</form>
<p class="hero__quick"><span>Popular:</span> <a href="/search?q=release%20date">release date</a> <a href="/search?q=pc">PC version</a> <a href="/search?q=radio">radio</a> <a href="/search?q=price">pricing</a> <a href="/search?q=online">online</a></p>
<div class="hero__status">
<div class="status"><span class="status__k">Scheduled launch</span><strong class="status__v" data-countdown data-date="${esc(SITE.releaseDate)}">${esc(fmtDate(SITE.releaseDate))}</strong><span class="status__s" data-countdown-text>As scheduled by Rockstar Games · PS5 and Xbox Series X|S</span></div>
<div class="status"><span class="status__k">Desk last reviewed</span><strong class="status__v">${esc(fmtDate(SITE.lastReviewed))}</strong><span class="status__s">Sources are linked on every entry</span></div>
</div>
</div>
</section>

<section class="statbar" aria-label="Desk at a glance"><div class="wrap"><ul class="statbar__list">${stats}</ul></div></section>

<section class="section" aria-labelledby="dash-h">
<div class="wrap">
<div class="section__head"><div><p class="eyebrow">Intel dashboard</p><h2 id="dash-h" class="section__title">Today’s briefing</h2></div><a class="more" href="/news">All news ${icons.arrow}</a></div>
<p class="section__note">Verified here means traced to a named source. Each label shows whether the source is Rockstar itself or third-party reporting.</p>
<div class="dash">
<div class="dash__main">
<div class="lead">${newsCard(lead)}</div>
<div class="dash__list">${rest.slice(0, 3).map((n) => newsCard(n, { compact: true })).join("")}</div>
</div>
<aside class="panel briefing" aria-labelledby="log-h">
<h3 id="log-h" class="panel__title">Latest briefings</h3>
<ol class="log">${log.map((l) => `<li><span class="log__d">${esc(l.label || fmtDate(l.date))}</span><span class="log__b">${badge(l.kind === "official" ? "official" : l.kind, l.type === "Rumor" ? "Rumor" : undefined)}</span><a href="${l.href}">${esc(l.title)}</a></li>`).join("")}</ol>
<h3 class="panel__title panel__title--sub">Coming up (scheduled by Rockstar)</h3>
<ul class="log log--next">${upcoming.map((u) => `<li><span class="log__d">${esc(fmtDate(u.date))}</span><a href="/updates#${u.slug}">${esc(u.title)}</a></li>`).join("")}</ul>
<a class="more" href="/updates">Open the full timeline ${icons.arrow}</a>
</aside>
</div>
</div>
</section>

<section class="section section--alt" aria-labelledby="off-h">
<div class="wrap">
<div class="section__head"><div><p class="eyebrow">Recent official updates</p><h2 id="off-h" class="section__title">What Rockstar has said</h2></div><a class="more" href="/updates">Full timeline ${icons.arrow}</a></div>
<ul class="rows">${recentOfficial.map((u) => `<li class="row"><div class="row__d">${dateTag(u.date)}</div><div class="row__b"><h3>${esc(u.title)}</h3><p>${esc(u.summary)}</p></div><a class="row__src" href="${esc(u.source.url)}" target="_blank" rel="noopener noreferrer">Source ${icons.external}<span class="sr-only"> (opens in a new tab): ${esc(u.source.name)}</span></a></li>`).join("")}</ul>
</div>
</section>

<section class="section" aria-labelledby="rum-h">
<div class="wrap">
<div class="section__head"><div><p class="eyebrow">Rumor watch</p><h2 id="rum-h" class="section__title">Recently discussed, never confirmed as fact</h2></div><a class="more" href="/rumors">All rumors ${icons.arrow}</a></div>
<p class="section__note">Every entry below is a claim from someone else. We show what is known, what is not, and where it came from.</p>
<div class="grid grid--3">${rumors.filter((r) => r.status !== "resolved").slice(0, 3).map((r) => rumorCard(r)).join("")}</div>
</div>
</section>

<section class="section section--alt" aria-labelledby="gd-h">
<div class="wrap">
<div class="section__head"><div><p class="eyebrow">Featured guides</p><h2 id="gd-h" class="section__title">Start here</h2></div><a class="more" href="/guides">All guides ${icons.arrow}</a></div>
<div class="grid grid--3">${["confirmed-vs-rumored-how-to-read-gta-6-news", "launch-checklist-dates-and-preloading", "standard-vs-ultimate-edition"].map((s) => guideCard(guides.find((g) => g.slug === s))).join("")}</div>
</div>
</section>

<section class="section" aria-labelledby="ex-h">
<div class="wrap">
<div class="section__head"><div><p class="eyebrow">Explore the desk</p><h2 id="ex-h" class="section__title">Six sections, one briefing</h2></div></div>
<div class="tiles">${tiles}</div>
</div>
</section>

<section class="section section--alt" aria-labelledby="key-h">
<div class="wrap split">
<div><p class="eyebrow">How we label</p><h2 id="key-h" class="section__title">Every claim wears a label</h2><p class="section__note">Our editorial promise is simple: we separate official information, reporting, analysis and rumor, and we never present one as the other.</p><a class="more" href="/about">Read our standards ${icons.arrow}</a></div>
<div>${legend}</div>
</div>
</section>

<section class="section" aria-labelledby="wl-h">
<div class="wrap">
<div class="callout-wide">
<div><p class="eyebrow">Personal Intel watchlist</p><h2 id="wl-h" class="section__title">Save what you want to follow</h2><p class="section__note">Use the Save button on any card to build a reading list. It is stored in this browser on this device only: no account, and it does not sync to other devices.</p></div>
<a class="btn btn--primary" href="/watchlist">Open watchlist <span class="count count--inline" data-watch-count hidden>0</span></a>
</div>
</div>
</section>`;

  return {
    path: "/",
    html: layout({
      title: SITE.name, path: "/", section: "home", body,
      description: "An independent GTA 6 briefing center: dated official updates, sourced news, clearly labeled rumors and practical guides. Unofficial fan project.",
      jsonld: SITE.baseUrl ? { "@context": "https://schema.org", "@type": "WebSite", name: SITE.name, url: SITE.baseUrl, potentialAction: { "@type": "SearchAction", target: `${SITE.baseUrl}/search?q={search_term_string}`, "query-input": "required name=search_term_string" } } : { "@context": "https://schema.org", "@type": "WebSite", name: SITE.name },
    }),
  };
}

// =====================================================================
// NEWS
// =====================================================================
export function newsIndex() {
  const body = `${pageHead({ eyebrow: "01 / News", title: "News", intro: "Sourced reporting and analysis about Grand Theft Auto VI. Every article is labeled so you can tell official information from reporting and from our own opinion." })}
<section class="section section--tight"><div class="wrap">
${legend}
<div class="filter-root" data-filters="news">
${filterBar({ searchLabel: "Search news", placeholder: "Search news by title, topic or keyword", sort: true, groups: [chipGroup("category", "Category", NEWS_CATEGORIES.map((c) => ({ value: c, label: c })))] })}
<div class="grid grid--3" data-list>${news.map((n) => newsCard(n)).join("")}</div>
${emptyState("No articles match.", "Try a different keyword or clear the filters.")}
</div>
</div></section>`;
  return { path: "/news", html: layout({ title: "News", path: "/news", section: "news", body, description: "GTA 6 news with clear labels: official source, reported or analysis. Search, filter by category and sort by newest." }) };
}

export function newsArticles() {
  return news.map((n) => {
    const rel = related(n, news);
    const path = `/news/${n.slug}`;
    const body = `<article class="article wrap wrap--narrow" itemscope>
<nav class="crumbs" aria-label="Breadcrumb"><a href="/news">News</a><span aria-hidden="true">/</span><span>${esc(n.category)}</span></nav>
<header class="article__head">
<div class="card__meta">${badge(n.verification)}<span class="meta__cat">${esc(n.category)}</span>${dateTag(n.date)}</div>
<h1 class="article__title">${esc(n.title)}</h1>
<p class="article__summary">${esc(n.summary)}</p>
<div class="article__actions">${saveBtn("news", n.slug, n.title)}<span class="muted">Saved to this browser only.</span></div>
</header>
<img class="article__hero" src="${artUrl("news", n.slug)}" alt="" width="640" height="360" decoding="async">
<div class="prose">${n.verification === "analysis" ? "" : ""}${blocks(n.body)}</div>
${sourcesBlock(n.sources)}
</article>
${rel.length ? `<section class="section section--alt"><div class="wrap"><h2 class="section__title section__title--sm">Related articles</h2><div class="grid grid--3">${rel.map((r) => newsCard(r, { compact: true })).join("")}</div></div></section>` : ""}`;
    return {
      path,
      html: layout({
        title: n.title, path, section: "news", body, type: "article", description: n.summary,
        jsonld: { "@context": "https://schema.org", "@type": "Article", headline: n.title, datePublished: n.date, description: n.summary, author: { "@type": "Organization", name: SITE.name }, publisher: { "@type": "Organization", name: SITE.name } },
      }),
    };
  });
}

// =====================================================================
// UPDATES
// =====================================================================
export function updatesPage() {
  const body = `${pageHead({ eyebrow: "02 / Updates", title: "Updates", intro: "A dated timeline of verified developments. Official announcements link to the Rockstar post; other reporting is labeled as such. Future dates are scheduled, not guaranteed." })}
<section class="section section--tight"><div class="wrap">
<ul class="legend" aria-label="Label key"><li>${badge("official")}<span>Rockstar published it</span></li><li>${badge("reported")}<span>Third-party reporting</span></li><li>${badge("scheduled")}<span>A future date Rockstar announced</span></li><li>${badge("website")}<span>About this site</span></li></ul>
<div class="filter-root" data-filters="updates">
${filterBar({ searchLabel: "Search updates", placeholder: "Search updates", groups: [chipGroup("filter", "Show", UPDATE_FILTERS)] })}
<ol class="tl" data-list>${updates.map((u) => updateItem(u, { today: TODAY })).join("")}</ol>
${emptyState("No updates match.", "Try a different keyword or clear the filters.")}
</div>
</div></section>`;
  return { path: "/updates", html: layout({ title: "Updates", path: "/updates", section: "updates", body, description: "A dated GTA 6 timeline of official announcements, release information, game features and website updates, each with a source link." }) };
}

// =====================================================================
// RUMORS
// =====================================================================
export function rumorsIndex() {
  const body = `${pageHead({ eyebrow: "03 / Rumors", title: "Rumors", intro: "Leaks reported by others and community speculation. Nothing on this page is confirmed unless it says so. We do not originate rumors, and we do not invent sources or evidence." })}
<section class="section section--tight"><div class="wrap">
<aside class="notice notice--warn" role="note"><strong>Read this first.</strong> Every entry here is a claim from someone else. “Confidence” is our plain-language editorial shorthand, not a scientific measure. Check Updates for what is official.</aside>
<dl class="confs">${Object.values(CONFIDENCE).map((c) => `<div><dt>${esc(c.label)}</dt><dd>${esc(c.note)}</dd></div>`).join("")}</dl>
<div class="filter-root" data-filters="rumors">
${filterBar({ searchLabel: "Search rumors", placeholder: "Search rumors", groups: [chipGroup("topic", "Topic", RUMOR_TOPICS), chipGroup("status", "Status", RUMOR_STATUS)] })}
<div class="grid grid--2" data-list>${rumors.map((r) => rumorCard(r)).join("")}</div>
${emptyState("No rumors match.", "Try a different keyword or clear the filters.")}
</div>
</div></section>`;
  return { path: "/rumors", html: layout({ title: "Rumors", path: "/rumors", section: "rumors", body, description: "GTA 6 rumors and leaks reported by others, each labeled with its source, date, status and a plain-language confidence label. Never presented as fact." }) };
}

export function rumorPages() {
  return rumors.map((r) => {
    const path = `/rumors/${r.slug}`;
    const rel = related(r, rumors, 2);
    const body = `<article class="article wrap wrap--narrow">
<nav class="crumbs" aria-label="Breadcrumb"><a href="/rumors">Rumors</a><span aria-hidden="true">/</span><span>${esc(topicLabel(RUMOR_TOPICS, r.topic))}</span></nav>
<header class="article__head">
<div class="card__meta">${badge("rumor")}${badge(r.status)}${dateTag(r.date, r.dateLabel)}</div>
<h1 class="article__title">${esc(r.title)}</h1>
<aside class="notice notice--warn" role="note"><strong>Rumor: not confirmed.</strong> This is a claim made by someone else. ${r.status === "resolved" ? "It has since been settled by official information, as explained below." : "Rockstar has not confirmed it."}</aside>
<div class="article__actions">${saveBtn("rumor", r.slug, r.title)}<span class="muted">Saved to this browser only.</span></div>
</header>
<div class="prose">
<h2>The claim</h2><p>${esc(r.claim)}</p>
<h2>Where it came from</h2><p>${esc(r.origin)}. Date: ${esc(r.dateLabel || fmtDate(r.date))}.</p>
<div class="twocol">
<div class="callout callout--known"><strong class="callout__title">What is known</strong><ul>${r.known.map((k) => `<li>${esc(k)}</li>`).join("")}</ul></div>
<div class="callout callout--unknown"><strong class="callout__title">What remains unconfirmed</strong><ul>${r.unconfirmed.map((k) => `<li>${esc(k)}</li>`).join("")}</ul></div>
</div>
<h2>Our confidence label</h2><p><strong>${esc(CONFIDENCE[r.confidence].label)}.</strong> ${esc(CONFIDENCE[r.confidence].note)} This is editorial shorthand, not a statistic.</p>
</div>
${sourcesBlock(r.sources)}
</article>
${rel.length ? `<section class="section section--alt"><div class="wrap"><h2 class="section__title section__title--sm">More from the rumor desk</h2><div class="grid grid--2">${rel.map((x) => rumorCard(x)).join("")}</div></div></section>` : ""}`;
    return { path, html: layout({ title: `Rumor: ${r.title}`, path, section: "rumors", body, type: "article", description: `Rumor, not confirmed: ${r.summary}` }) };
  });
}

// =====================================================================
// QUESTIONS
// =====================================================================
export function questionsPage() {
  const body = `${pageHead({ eyebrow: "04 / Questions", title: "Questions", intro: "Common questions with sourced answers. Search, filter by topic, or draft a question of your own." })}
<section class="section section--tight"><div class="wrap">
<div class="filter-root" data-filters="questions">
${filterBar({ searchLabel: "Search questions", placeholder: "Search questions and answers", groups: [chipGroup("topic", "Topic", QUESTION_TOPICS)] })}
<div class="qa-list" data-list>${QUESTIONS.map((q) => qaItem(q, topicLabel(QUESTION_TOPICS, q.topic))).join("")}</div>
${emptyState("No questions match.", "Try different words, or draft your own question below.")}
</div>

<section class="ask" id="ask" aria-labelledby="ask-h">
<h2 id="ask-h" class="section__title section__title--sm">Ask a question</h2>
<aside class="notice notice--demo" role="note"><strong>Demo form: nothing is sent or saved.</strong> This site has no database yet, so your question is not stored, published or answered. You can check it here and copy it${SITE.contactEmail ? " or send it by email" : ""}. Community answers, moderation and accounts are planned for a later stage.</aside>
<form id="ask-form" class="form" novalidate${SITE.contactEmail ? ` data-mailto="${esc(SITE.contactEmail)}"` : ""}>
<div class="form__row"><label for="ask-topic">Topic</label>
<select id="ask-topic" name="topic" required aria-describedby="ask-topic-err"><option value="">Choose a topic…</option>${QUESTION_TOPICS.filter((t) => t.value !== "site").map((t) => `<option value="${esc(t.value)}">${esc(t.label)}</option>`).join("")}</select>
<p class="field-error" id="ask-topic-err" hidden></p></div>
<div class="form__row"><label for="ask-q">Your question</label>
<textarea id="ask-q" name="question" rows="4" maxlength="300" required aria-describedby="ask-q-help ask-q-err"></textarea>
<p class="hint" id="ask-q-help"><span data-chars>0</span> / 300 characters. Please don’t include personal information.</p>
<p class="field-error" id="ask-q-err" hidden></p></div>
<button class="btn btn--primary" type="submit">Check my question</button>
</form>
<div id="ask-result" class="notice notice--result" hidden tabindex="-1"></div>
</section>
</div></section>`;
  return { path: "/questions", html: layout({ title: "Questions", path: "/questions", section: "questions", body, description: "Searchable GTA 6 questions and sourced answers by topic: release information, platforms, gameplay, map, vehicles and online features." }) };
}

// =====================================================================
// GUIDES
// =====================================================================
export function guidesIndex() {
  const tags = topTags(10).filter((t) => !["beginner", "explainer", "checklist", "speculative"].includes(t));
  const body = `${pageHead({ eyebrow: "05 / Guides", title: "Guides", intro: "Practical explainers and checklists. Guides only state mechanics as fact when they are verified, and speculative guides are labeled." })}
<section class="section section--tight"><div class="wrap">
<div class="filter-root" data-filters="guides">
${filterBar({ searchLabel: "Search guides", placeholder: "Search guides", groups: [chipGroup("level", "Type", GUIDE_LEVELS.map((l) => ({ value: l, label: l }))), chipGroup("tag", "Topic", tags.map((t) => ({ value: t, label: t })))] })}
<div class="grid grid--3" data-list>${guides.map((g) => guideCard(g)).join("")}</div>
${emptyState("No guides match.", "Try a different keyword or clear the filters.")}
</div>
</div></section>`;
  return { path: "/guides", html: layout({ title: "Guides", path: "/guides", section: "guides", body, description: "GTA 6 guides and explainers: launch checklists, editions, Leonida, weather, music and more. Search and filter by type or topic." }) };
}

export function guidePages() {
  return guides.map((g) => {
    const path = `/guides/${g.slug}`;
    const rel = related(g, guides);
    const body = `<article class="article wrap wrap--narrow">
<nav class="crumbs" aria-label="Breadcrumb"><a href="/guides">Guides</a><span aria-hidden="true">/</span><span>${esc(g.level)}</span></nav>
<header class="article__head">
<div class="card__meta">${g.level === "Speculative" ? badge("speculation") : `<span class="badge badge--level">${esc(g.level)}</span>`}<span class="meta__cat">${g.readMinutes} min read</span>${dateTag(g.date)}</div>
<h1 class="article__title">${esc(g.title)}</h1>
<p class="article__summary">${esc(g.summary)}</p>
<div class="article__actions">${saveBtn("guide", g.slug, g.title)}<span class="muted">Saved to this browser only.</span></div>
</header>
<div class="prose">${blocks(g.body)}</div>
${sourcesBlock(g.sources)}
</article>
${rel.length ? `<section class="section section--alt"><div class="wrap"><h2 class="section__title section__title--sm">Related guides</h2><div class="grid grid--3">${rel.map((x) => guideCard(x)).join("")}</div></div></section>` : ""}`;
    return {
      path,
      html: layout({ title: g.title, path, section: "guides", body, type: "article", description: g.summary, jsonld: { "@context": "https://schema.org", "@type": "Article", headline: g.title, datePublished: g.date, description: g.summary, author: { "@type": "Organization", name: SITE.name } } }),
    };
  });
}

// =====================================================================
// MEMBERSHIP PLANS (planned; nothing is purchasable)
// =====================================================================
export function membership() {
  const rows = [
    ["Dashboard, News, Updates, Rumors, Questions and Guides", "free", "free"],
    ["Source links, labels and rumor status on every entry", "free", "free"],
    ["Site-wide search with filters", "free", "free"],
    ["Watchlist saved in this browser", "free", "free"],
    ["Longer research reports and analysis", "", "plus"],
    ["Premium briefings and organized intelligence reports", "", "plus"],
    ["Advanced content filters", "", "plus"],
    ["Watchlist that syncs across devices (needs accounts)", "", "plus"],
    ["Member research summaries and collections", "", "plus"],
  ];
  const cell = (v, plan) => (v ? (plan === "free" ? `<span class="yes">${icons.check}<span>Available now</span></span>` : `<span class="soon">${badge("planned")}</span>`) : `<span class="no" aria-label="Not included">·</span>`);
  const body = `${pageHead({ eyebrow: "06 / Membership Plans", title: "Membership Plans", intro: "The free experience is the whole site today. Intel Plus is a proposed plan that does not exist yet." })}
<section class="section section--tight"><div class="wrap">
<aside class="notice notice--warn" role="note"><strong>Planned, not available.</strong> You cannot buy, start or activate Intel Plus, and there is no checkout, account or premium access on this site today. The $20 per month figure is a proposal, not a validated price.</aside>
<div class="plans">
<article class="plan plan--free" aria-labelledby="plan-free-h">
<p class="eyebrow">Available now</p><h2 id="plan-free-h" class="plan__name">The Briefing</h2>
<p class="plan__price"><strong>$0</strong><span>free</span></p>
<p>A genuinely useful, ad-free starting point: everything you see on this site today.</p>
<ul class="plan__list"><li>Full News, Updates, Rumors, Questions and Guides</li><li>Source links and clear labels</li><li>Site-wide search</li><li>Local watchlist on this device</li></ul>
<a class="btn btn--primary" href="/news">Start reading</a>
</article>
<article class="plan plan--plus" aria-labelledby="plan-plus-h">
<p class="eyebrow">Planned · Coming later</p><h2 id="plan-plus-h" class="plan__name">Intel Plus</h2>
<p class="plan__price"><strong>$20</strong><span>per month · proposed</span></p>
<p>An expanded research layer for readers who want more depth and organization. Features are proposals and may change.</p>
<ul class="plan__list"><li>Everything in the free plan</li><li>Detailed research and analysis</li><li>Premium briefings and intelligence reports</li><li>Advanced filters and synced reading lists</li><li>Member research summaries and collections</li></ul>
<button class="btn btn--disabled" type="button" disabled aria-disabled="true">Not on sale yet</button>
</article>
</div>

<h2 class="section__title section__title--sm">Free vs. proposed Intel Plus</h2>
<div class="tablewrap"><table class="compare"><caption class="sr-only">Comparison of the free plan and the proposed Intel Plus plan</caption>
<thead><tr><th scope="col">Feature</th><th scope="col">Free</th><th scope="col">Intel Plus (proposed)</th></tr></thead>
<tbody>${rows.map(([f, a, b]) => `<tr><th scope="row">${esc(f)}</th><td>${cell(a, "free")}</td><td>${b === "plus" ? cell("x", "plus") : `<span class="muted">Included</span>`}</td></tr>`).join("")}</tbody></table></div>

<div class="split split--top">
<div>
<h2 class="section__title section__title--sm">What has to be true before Intel Plus exists</h2>
<ul class="checklist"><li>Enough readers tell us premium research would be worth paying for.</li><li>Accounts, billing and access control are built and tested.</li><li>There is enough premium work to justify a subscription.</li></ul>
<p class="muted">We will not promise earnings, guaranteed access or a launch date until those are real.</p>
</div>
<div class="sample">
<p class="eyebrow">${"Sample format"} ${badge("sample")}</p>
<h3>Sample briefing layout</h3>
<p class="muted">A mock-up of how a premium briefing could be organized, using only facts already public on this site.</p>
<dl class="sample__dl"><div><dt>Situation</dt><dd>Launch is scheduled for November 19, with preload from November 12.</dd></div><div><dt>Confirmed</dt><dd>Platforms, editions, pricing, soundtrack album.</dd></div><div><dt>Open questions</dt><dd>Online mode, PC version, remaining radio stations.</dd></div><div><dt>Watch next</dt><dd>Any new Rockstar Newswire post.</dd></div></dl>
</div>
</div>

<h2 class="section__title section__title--sm">Frequently asked</h2>
<div class="faq">
<details><summary>Can I subscribe today?</summary><p>No. Nothing is sold on this site, and there is no payment, account or premium access.</p></details>
<details><summary>Is $20 per month final?</summary><p>No. It is a working proposal we will test before committing to anything.</p></details>
<details><summary>Does my watchlist follow me to my phone?</summary><p>Not yet. Your watchlist lives in this browser on this device only. Syncing needs accounts, which are a possible future feature.</p></details>
<details><summary>Will the free plan shrink?</summary><p>The free plan is everything on the site today. Any future premium work would be additional.</p></details>
</div>
${SITE.contactEmail ? `<p class="muted">Tell us what you would want from Intel Plus: <a href="mailto:${esc(SITE.contactEmail)}?subject=Intel%20Plus%20feedback">send feedback by email</a>.</p>` : ""}
</div></section>`;
  return { path: "/membership", html: layout({ title: "Membership Plans", path: "/membership", section: "membership", body, description: "The free Leonida Intel experience and the proposed Intel Plus plan at $20 per month. Planned only: payments and premium access are not available." }) };
}

// =====================================================================
// SEARCH, WATCHLIST, ABOUT, 404
// =====================================================================
export function searchPage() {
  const tags = topTags(14);
  const types = [{ value: "news", label: "News" }, { value: "update", label: "Updates" }, { value: "rumor", label: "Rumors" }, { value: "question", label: "Questions" }, { value: "guide", label: "Guides" }];
  const body = `${pageHead({ eyebrow: "Search & discovery", title: "Search", intro: "Search news, updates, rumors, questions and guides in one place." })}
<section class="section section--tight"><div class="wrap" data-search-root>
<form class="search-form" action="/search" method="get" role="search">
<label class="sr-only" for="search-q">Search Leonida Intel</label>${icons.search}
<input id="search-q" name="q" type="search" placeholder="Try: release date, PC, radio, price" autocomplete="off" enterkeyhint="search" data-q data-focus-key="/">
<button class="btn btn--primary" type="submit">Search</button>
</form>
<div class="chips" role="group" aria-label="Content type" data-group="type"><span class="chips__label" aria-hidden="true">Type</span><button type="button" class="chip" data-value="all" aria-pressed="true">All</button>${types.map((t) => `<button type="button" class="chip" data-value="${t.value}" aria-pressed="false">${t.label}</button>`).join("")}</div>
<div class="chips" role="group" aria-label="Topic tags" data-group="tag"><span class="chips__label" aria-hidden="true">Topic</span><button type="button" class="chip" data-value="all" aria-pressed="true">Any</button>${tags.map((t) => `<button type="button" class="chip" data-value="${esc(t)}" aria-pressed="false">${esc(t)}</button>`).join("")}</div>
<p class="filters__count" data-count aria-live="polite"></p>
<ol class="results" data-results></ol>
<div class="empty" data-empty hidden><p class="empty__title">Nothing matches that search.</p><p>Check the spelling, try fewer words, or browse a section instead.</p><p class="empty__links"><a href="/news">News</a><a href="/updates">Updates</a><a href="/rumors">Rumors</a><a href="/questions">Questions</a><a href="/guides">Guides</a></p><button type="button" class="btn btn--ghost" data-reset>Clear search and filters</button></div>
<noscript><p class="notice notice--warn">Search needs JavaScript. You can still browse every section from the menu.</p></noscript>
</div></section>`;
  return { path: "/search", html: layout({ title: "Search", path: "/search", section: "search", body, description: "Search every GTA 6 news article, update, rumor, question and guide on Leonida Intel. Filter by content type and topic." }) };
}

export function watchlistPage() {
  const body = `${pageHead({ eyebrow: "Personal Intel watchlist", title: "Your watchlist", intro: "Articles, rumors, updates, guides and questions you saved." })}
<section class="section section--tight"><div class="wrap" data-watchlist-root>
<aside class="notice notice--demo" role="note"><strong>Stored on this device only.</strong> Your watchlist is saved in this browser’s local storage. It does not sync to other devices or browsers, there are no accounts yet, and clearing your browser data will remove it.</aside>
<div class="wl__bar"><p class="filters__count" data-count aria-live="polite"></p><button type="button" class="btn btn--ghost" data-clear hidden>Clear all</button></div>
<ul class="wl" data-wl-list></ul>
<div class="empty" data-empty hidden><p class="empty__title">Your watchlist is empty.</p><p>Use the Save button on any card or article to keep it here.</p><p class="empty__links"><a href="/news">Browse news</a><a href="/rumors">Browse rumors</a><a href="/guides">Browse guides</a></p></div>
<noscript><p class="notice notice--warn">The watchlist needs JavaScript and browser storage.</p></noscript>
</div></section>`;
  return { path: "/watchlist", html: layout({ title: "Watchlist", path: "/watchlist", section: "watchlist", body, noindex: true, description: "Your personal Leonida Intel reading list, stored in this browser only." }) };
}

export function aboutPage() {
  const body = `${pageHead({ eyebrow: "About", title: "About & editorial standards", intro: "Who we are, how we label information, and how we handle sources, corrections and your data." })}
<section class="section section--tight"><div class="wrap wrap--narrow"><div class="prose">
<aside class="notice notice--warn" role="note"><strong>Unofficial fan project.</strong> ${esc(SITE.disclaimer)}</aside>
<h2>What this is</h2><p>Leonida Intel is an independent information site about Grand Theft Auto VI. It is written by fans, with original writing and original artwork. We do not use game assets, and any images on the site are our own illustrations.</p>
<h2>How we label information</h2>
<dl class="defs">
<div><dt>${badge("official")}</dt><dd>Published by Rockstar Games itself, such as a Newswire post, trailer or the official game site.</dd></div>
<div><dt>${badge("reported")}</dt><dd>Reporting by journalists or outlets, linked to its source. We say when we have not seen the primary material.</dd></div>
<div><dt>${badge("analysis")}</dt><dd>Our interpretation. It rests on cited facts but is opinion and may be wrong.</dd></div>
<div><dt>${badge("rumor")}</dt><dd>A claim from someone else. Entries show the source, date, what is known and what is unconfirmed, plus a status and a plain-language confidence label that is editorial shorthand, not a measurement.</dd></div>
<div><dt>${badge("speculation")}</dt><dd>An educated guess clearly separated from facts.</dd></div>
<div><dt>${badge("sample")}</dt><dd>Illustrative layouts, such as the proposed membership briefing. Not real product content.</dd></div>
</dl>
<h2>Sourcing</h2><p>We prefer Rockstar’s own announcements for anything about confirmed game information. We link to sources and describe them in our own words; we do not copy articles. We do not invent quotes, sources, release dates or features. External links were gathered on ${esc(fmtDate(SITE.lastReviewed))} and can change.</p>
<h2>Corrections</h2><p>If something is wrong, tell us and we will correct it visibly rather than quietly. ${SITE.contactEmail ? `Email <a href="mailto:${esc(SITE.contactEmail)}">${esc(SITE.contactEmail)}</a>.` : "A public contact address has not been added to this site yet."}</p>
<h2>Privacy and storage</h2><p>This site sets no tracking cookies and loads no third-party scripts. Your watchlist is stored in your browser’s local storage on this device and is never sent to a server. The question form is a demo and does not transmit anything.</p>
<h2>Trademarks</h2><p>Grand Theft Auto, Rockstar Games and related names are trademarks of their owners. Their use here is for identification and commentary only.</p>
</div></div></section>`;
  return { path: "/about", html: layout({ title: "About & editorial standards", path: "/about", section: "about", body, description: "About Leonida Intel: an unofficial, independent GTA 6 fan project, how we label sources, handle corrections and treat your data." }) };
}

export function notFoundPage() {
  const body = `<section class="page-head"><div class="wrap"><p class="eyebrow">Error 404</p><h1 class="page-head__title">That page isn’t on the map</h1><p class="page-head__intro">The address may be mistyped or the page may have moved. Try one of the sections below or search.</p>
<p class="empty__links"><a href="/">Home</a>${NAV.map((n) => `<a href="${n.href}">${esc(n.label)}</a>`).join("")}<a href="/search">Search</a></p></div></section>`;
  return { path: "/404", file: "404.html", html: layout({ title: "Page not found", path: "/404", section: "", body, noindex: true, description: "The page you were looking for could not be found on Leonida Intel." }) };
}

export const allCardArt = () => [
  ...NEWS.map((n) => ({ type: "news", slug: n.slug, category: n.category })),
  ...GUIDES.map((g) => ({ type: "guide", slug: g.slug, category: "" })),
];
