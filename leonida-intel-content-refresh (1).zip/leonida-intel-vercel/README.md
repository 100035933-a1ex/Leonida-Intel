# Leonida Intel

An **unofficial, independent GTA 6 information site**: sourced news, a dated updates timeline, clearly labeled rumors, searchable questions, guides, and a planned (not yet available) membership page.

It is a **zero-dependency static site**. A small Node script (`build.mjs`) turns the content files in `src/content/` into plain HTML pages in `dist/`. No framework, no database, no API keys, no paid services.

> Leonida Intel is a fan project. It is not affiliated with, endorsed by, or sponsored by Rockstar Games or Take-Two Interactive. No game assets are used; all artwork is original SVG.

## What is in the site

| Section | URL | Notes |
|---|---|---|
| Intel Dashboard (home) | `/` | latest verified news, official updates, rumor watch, featured guides, briefing log, scheduled dates, six quick links |
| News | `/news`, `/news/<slug>` | search, category filter, sort, labels (Official / Reported / Analysis), related articles |
| Updates | `/updates` | dated timeline, source links, filters, `#slug` deep links |
| Rumors | `/rumors`, `/rumors/<slug>` | every entry labeled Rumor, with status, confidence label, known vs. unconfirmed |
| Questions | `/questions` | search, topic filter, **demo** question form (nothing is sent or stored) |
| Guides | `/guides`, `/guides/<slug>` | search, type and topic filters, speculative guides labeled |
| Membership Plans | `/membership` | free plan vs. *proposed* Intel Plus ($20/month, unvalidated). No checkout, no accounts |
| Search | `/search?q=...` | site-wide, content-type and tag filters, empty states |
| Watchlist | `/watchlist` | saved items, stored in this browser only |
| About | `/about` | disclaimer, label definitions, corrections, privacy |

## Run locally

Requires Node 18 or newer (no `npm install` needed).

```bash
npm run build        # writes the site to ./dist
npm run dev          # build + preview at http://localhost:3000 (mimics Vercel clean URLs and 404)
npm test             # build + automated checks (links, metadata, CSP-safety, membership honesty)
```

Optional browser tests (not needed to deploy): `pip install playwright && playwright install chromium`, then `node build.mjs && python tests/e2e.py`.

## Deploy to Vercel (step by step)

1. Unzip this project. The folder should contain `package.json`, `vercel.json`, `build.mjs`, `src/`, `public/`.
2. Create a **new GitHub repository** (private is fine) and upload the *contents* of the folder to the repository root (so `vercel.json` is at the top level, not inside a sub-folder).
3. Go to [vercel.com](https://vercel.com), sign in, choose **Add New → Project**, and import the repository.
4. Confirm these settings (they are read from `vercel.json`, so they should already be filled in):
   - **Framework Preset:** Other
   - **Build Command:** `node build.mjs`
   - **Output Directory:** `dist`
   - **Install Command:** leave default (there are no dependencies)
   - **Node.js Version:** 18.x or newer (22.x is fine)
5. Click **Deploy**. You get a live `*.vercel.app` URL in about a minute.
6. Open the live URL and click through the six sections. Visit a deep link such as `/news/release-date-history` and refresh it: it should load (this is what `cleanUrls` provides).
7. *Optional:* **Settings → Domains** to add your own domain, following the DNS values Vercel shows you.

Every push to the repository redeploys automatically.

### Optional environment variables (Settings → Environment Variables)

| Variable | Purpose |
|---|---|
| `SITE_URL` | Your public address, e.g. `https://leonidaintel.com`. Used for canonical URLs, social-sharing image URLs and `sitemap.xml`. If unset, Vercel's `VERCEL_PROJECT_PRODUCTION_URL` is used automatically. |
| `CONTACT_EMAIL` | Enables optional "send by email" links on the question form, membership page and corrections section. Never required. |

No secrets are stored in the code. Do not put secrets in these two variables; both end up in public pages.

## Content refresh workflow (automatic discovery + human review)

The site is static, so it does not silently publish unverified claims. A GitHub Actions workflow now checks Rockstar's official GTA VI Newswire archive every six hours and when manually triggered. It compares discovered article URLs against the sources already used in News, Updates, and Rumors, then writes newly discovered links to `content-refresh/rockstar-newswire-inbox.json`.

**Important:** the refresh is a discovery system, not an auto-publisher. Every candidate remains marked `needs-editorial-review`; an editor must open the official source, verify its date and claims, write an original summary, and add it to the appropriate `src/content/` file. This prevents a changed page layout, unrelated article, rumor, or malformed feed item from being published as fact. The scheduled workflow commits inbox changes only; it never changes the public site's article content on its own. GitHub Actions must be enabled in the repository for scheduled runs.

To run the check manually from a local copy:

```bash
node scripts/refresh-newswire.mjs
```

The script needs network access to fetch Rockstar's archive. It writes to `content-refresh/rockstar-newswire-inbox.json` and leaves the public content files untouched.

## Adding content

All published content is data in `src/content/`. Add an object, run `npm test`, push. Pages, filters, related links, the search index and the watchlist pick it up automatically.

- **News:** append to `NEWS` in `news.mjs`. Choose `verification`: `official`, `reported` or `analysis`.
- **Updates:** append to `UPDATES` in `updates.mjs` with a `source` for anything that depends on an outside source.
- **Rumors:** append to `RUMORS` in `rumors.mjs`. Always fill `origin`, `known`, `unconfirmed`, `status`, `confidence`.
- **Questions / Guides:** `questions.mjs`, `guides.mjs`.
- **Sources:** reusable links live in `sources.mjs`.

Editorial rules baked into the structure: never invent quotes, sources, dates or features; paraphrase instead of copying; label rumors and speculation; link to the primary source whenever one exists. Update `lastReviewed` and `releaseDate` in `src/site.mjs` when you review content.

## Honest limitations and what needs an external service later

| Feature | Today | Needs for the real thing |
|---|---|---|
| Question submissions | Demo only. Validates, then shows a draft the visitor can copy. Nothing is stored or sent. | A backend or form service, plus moderation. Structure notes are in `questions.mjs`. |
| Watchlist | Stored in the browser's `localStorage`. Per browser and device; not synced. | User accounts and a database for sync. |
| Intel Plus | Page and plan comparison only. Planned, labeled as proposed. No checkout, accounts or premium content. | Authentication, a payment provider (e.g. Stripe), access control, and premium content. |
| Content freshness | Published content is static and changes only when reviewed content is committed and deployed. A GitHub Actions workflow checks the official Rockstar Newswire archive every six hours and queues new links for review. | Human review and editing remain required before any item is published. Enable GitHub Actions in the repository. |
| Analytics | None (no tracking). | Add a privacy-friendly analytics script if you want to learn which sections attract readers, and update `vercel.json`'s Content-Security-Policy and the privacy text on `/about`. |
| External links | Gathered from searches on 2026-10-18 and **not re-verified from this build environment** (no outbound network). | Click through every source link before launch; pages can move. |

## Project structure

```
build.mjs            static generator (Node, no dependencies)
vercel.json          build command, output dir, clean URLs, security headers + CSP
src/site.mjs         name, nav, release date, env-driven config
src/content/*.mjs    all content (news, updates, rumors, questions, guides, sources)
src/pages.mjs        page templates     src/render.mjs  layout + components
src/art.mjs          procedural original card art
public/              styles.css, app.js, assets/ (mark, hero, atlas, social images)
scripts/             serve.mjs (preview), check.mjs (verification), refresh-newswire.mjs (review queue), asset generators
.github/workflows/   scheduled official Newswire inbox refresh
content-refresh/     machine-discovered source links awaiting human review
tests/e2e.py         optional Playwright browser tests
```

## Accessibility and security notes

Skip link, landmarks, visible focus states, keyboard-operable menu/filters/accordions, labels on all controls, text (not color alone) on every status badge, reduced-motion support. A strict Content-Security-Policy is set in `vercel.json` (own-origin scripts/styles only), so there are no inline scripts or styles; keep it that way when editing.

## Growth stages

1. **Launch** the core site on Vercel (this project).
2. **Promote** with short-form video and social posts that link to specific pages (`/news/...`, `/rumors/...`).
3. **Learn** which sections get visits and return traffic (add analytics when ready).
4. **Validate** whether readers would pay for Intel Plus before building payments. Nothing here promises revenue or that anyone will pay.
5. **Build** accounts, subscriptions and community features only when there is a sound reason.
